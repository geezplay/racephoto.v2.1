import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getSettings } from '../services/api';
import {
    Home,
    ShoppingCart,
    Wallet,
    FolderDown,
    Camera,
    Users,
    Settings,
    Clock,
    Upload,
    UserCog,
    LogOut,
    User,
    ChevronLeft,
    ChevronRight,
    ExternalLink,
    Image,
    CalendarDays
} from 'lucide-react';

export default function AdminLayout({ children, title, subtitle }) {
    const location = useLocation();
    const navigate = useNavigate();
    const { user, logout, isSuperAdmin } = useAuth();
    const [sidebarOpen, setSidebarOpen] = useState(true);
    const [uploadMenuOpen, setUploadMenuOpen] = useState(false);
    const [siteSettings, setSiteSettings] = useState({ site_name: 'RacePhoto', logo_url: null });

    useEffect(() => {
        const fetchSettings = async () => {
            try {
                const res = await getSettings();
                if (res.data) {
                    setSiteSettings({
                        site_name: res.data.site_name || 'RacePhoto',
                        logo_url: res.data.logo_url || null
                    });
                }
            } catch (error) {
                console.error('Error fetching site settings:', error);
            }
        };
        fetchSettings();
    }, []);

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    const isActive = (path) => location.pathname === path;

    // Menu items based on role
    const menuItems = [
        { name: 'Dashboard', icon: Home, href: '/admin', active: isActive('/admin') },
        { name: 'Transaksi', icon: ShoppingCart, href: '/admin/transactions', active: isActive('/admin/transactions') },
        // Regular admin only
        ...(!isSuperAdmin() ? [
            { name: 'Saldo & Penarikan', icon: Wallet, href: '/admin/balance', active: isActive('/admin/balance') },
        ] : []),
        // Super admin only
        ...(isSuperAdmin() ? [
            { name: 'Event Calendar', icon: CalendarDays, href: '/admin/upcoming-events', active: isActive('/admin/upcoming-events') },
            { name: 'Recap Foto', icon: FolderDown, href: '/admin/recap', active: isActive('/admin/recap') },
            { name: 'Fotografer', icon: Camera, href: '/admin/photographers', active: isActive('/admin/photographers') },
            { name: 'Sponsor', icon: Users, href: '/admin/sponsors', active: isActive('/admin/sponsors') },
            { name: 'Pengaturan', icon: Settings, href: '/admin/settings', active: isActive('/admin/settings') },
            { name: 'Pending Events', icon: Clock, href: '/admin/pending-events', active: isActive('/admin/pending-events') },
            { name: 'Request Penarikan', icon: Upload, href: '/admin/withdrawals', active: isActive('/admin/withdrawals') },
            { name: 'Kelola Admin', icon: UserCog, href: '/admin/users', active: isActive('/admin/users') },
        ] : []),
    ];

    return (
        <div style={{
            minHeight: '100vh',
            background: '#020202',
            color: 'white',
            fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
        }}>
            {/* Sidebar */}
            <aside style={{
                position: 'fixed',
                top: 0,
                left: 0,
                height: '100%',
                width: sidebarOpen ? '256px' : '80px',
                background: '#0a0a0a',
                borderRight: '1px solid rgba(255,255,255,0.1)',
                zIndex: 40,
                transition: 'width 0.3s',
                display: 'flex',
                flexDirection: 'column'
            }}>
                {/* Logo */}
                <div style={{
                    padding: '1rem',
                    borderBottom: '1px solid rgba(255,255,255,0.1)',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.75rem'
                }}>
                    {siteSettings.logo_url ? (
                        <img
                            src={`${import.meta.env.VITE_API_URL || 'http://localhost:5000'}${siteSettings.logo_url}`}
                            alt={siteSettings.site_name}
                            style={{
                                height: '40px',
                                width: 'auto',
                                maxWidth: sidebarOpen ? '180px' : '40px',
                                objectFit: 'contain'
                            }}
                        />
                    ) : (
                        <>
                            <div style={{
                                background: '#39FF14',
                                padding: '0.5rem',
                                borderRadius: '12px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center'
                            }}>
                                <Image size={24} color="black" />
                            </div>
                            {sidebarOpen && (
                                <div>
                                    <h1 style={{
                                        fontWeight: '900',
                                        fontSize: '1.125rem',
                                        letterSpacing: '-0.02em',
                                        textTransform: 'uppercase',
                                        fontStyle: 'italic'
                                    }}>{siteSettings.site_name}</h1>
                                    <p style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.4)' }}>Admin Panel</p>
                                </div>
                            )}
                        </>
                    )}
                </div>

                {/* Menu */}
                <nav style={{ padding: '1rem', flex: 1, overflowY: 'auto' }}>
                    <p style={{
                        fontSize: '10px',
                        fontWeight: '900',
                        color: 'rgba(255,255,255,0.3)',
                        textTransform: 'uppercase',
                        letterSpacing: '0.1em',
                        marginBottom: '1rem',
                        textAlign: sidebarOpen ? 'left' : 'center'
                    }}>
                        {sidebarOpen ? 'Menu' : '•••'}
                    </p>
                    <ul style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                        {menuItems.map((item) => {
                            const IconComponent = item.icon;
                            return (
                                <li key={item.name}>
                                    <Link
                                        to={item.href}
                                        style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '0.75rem',
                                            padding: '0.75rem 1rem',
                                            borderRadius: '12px',
                                            transition: 'all 0.2s',
                                            textDecoration: 'none',
                                            background: item.active ? '#39FF14' : 'transparent',
                                            color: item.active ? 'black' : 'rgba(255,255,255,0.6)',
                                            fontWeight: item.active ? '700' : '500'
                                        }}
                                    >
                                        <IconComponent size={20} />
                                        {sidebarOpen && <span>{item.name}</span>}
                                    </Link>
                                </li>
                            );
                        })}
                    </ul>
                </nav>

                {/* Toggle Button */}
                <button
                    onClick={() => setSidebarOpen(!sidebarOpen)}
                    style={{
                        position: 'absolute',
                        right: '-12px',
                        top: '80px',
                        background: '#39FF14',
                        color: 'black',
                        border: 'none',
                        padding: '0.375rem',
                        borderRadius: '50%',
                        cursor: 'pointer',
                        boxShadow: '0 4px 6px rgba(0,0,0,0.3)',
                        transition: 'transform 0.2s',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}
                >
                    {sidebarOpen ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
                </button>

                {/* User Profile */}
                <div style={{
                    padding: '1rem',
                    borderTop: '1px solid rgba(255,255,255,0.1)',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.75rem'
                }}>
                    <div style={{
                        background: 'rgba(57,255,20,0.2)',
                        padding: '0.5rem',
                        borderRadius: '50%',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <User size={20} color="#39FF14" />
                    </div>
                    {sidebarOpen && (
                        <div style={{ flex: 1, minWidth: 0 }}>
                            <p style={{ fontWeight: '700', fontSize: '0.875rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                {user?.name || 'Admin'}
                            </p>
                            <p style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.4)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                {user?.email}
                            </p>
                        </div>
                    )}
                    <button
                        onClick={handleLogout}
                        style={{
                            padding: '0.5rem',
                            borderRadius: '8px',
                            border: 'none',
                            background: 'transparent',
                            color: 'rgba(255,255,255,0.6)',
                            cursor: 'pointer',
                            transition: 'all 0.2s',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}
                        title="Logout"
                    >
                        <LogOut size={18} />
                    </button>
                </div>
            </aside>

            {/* Main Content */}
            <main style={{
                marginLeft: sidebarOpen ? '256px' : '80px',
                transition: 'margin-left 0.3s'
            }}>
                {/* Top Header */}
                <header style={{
                    background: 'rgba(10,10,10,0.8)',
                    backdropFilter: 'blur(12px)',
                    borderBottom: '1px solid rgba(255,255,255,0.1)',
                    padding: '1rem 1.5rem',
                    position: 'sticky',
                    top: 0,
                    zIndex: 30,
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                }}>
                    <div>
                        <h2 style={{
                            fontSize: '1.875rem',
                            fontWeight: '900',
                            textTransform: 'uppercase',
                            fontStyle: 'italic'
                        }}>
                            {title || 'Control Panel'}
                        </h2>
                        <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.875rem' }}>
                            {subtitle || `Selamat datang kembali, ${user?.name || 'Admin'}!`}
                        </p>
                    </div>
                    <Link
                        to="/"
                        style={{
                            color: 'rgba(255,255,255,0.4)',
                            textDecoration: 'none',
                            fontSize: '0.875rem',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '0.5rem',
                            background: 'rgba(255,255,255,0.05)',
                            padding: '0.5rem 1rem',
                            borderRadius: '12px',
                            border: '1px solid rgba(255,255,255,0.1)',
                            transition: 'all 0.2s'
                        }}
                    >
                        Lihat Website <ExternalLink size={14} />
                    </Link>
                </header>

                {/* Page Content */}
                <div style={{ padding: '1.5rem' }}>
                    {children}
                </div>
            </main>
        </div>
    );
}
