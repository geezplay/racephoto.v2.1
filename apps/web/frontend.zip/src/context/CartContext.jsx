import { createContext, useContext, useState, useEffect } from 'react';

const CartContext = createContext(null);

export const useCart = () => {
    const context = useContext(CartContext);
    if (!context) {
        throw new Error('useCart must be used within CartProvider');
    }
    return context;
};

export const CartProvider = ({ children }) => {
    const [items, setItems] = useState([]);
    const [isInitialized, setIsInitialized] = useState(false);

    // Load cart from localStorage on mount
    useEffect(() => {
        const savedCart = localStorage.getItem('racephoto_cart');
        if (savedCart) {
            try {
                const parsedCart = JSON.parse(savedCart);
                console.log('Loaded cart from localStorage:', parsedCart);
                setItems(parsedCart);
            } catch (e) {
                console.error('Failed to parse cart from localStorage:', e);
                setItems([]);
            }
        }
        setIsInitialized(true);
    }, []);

    // Save cart to localStorage whenever it changes (only after initialization)
    useEffect(() => {
        if (isInitialized) {
            console.log('Saving cart to localStorage:', items);
            localStorage.setItem('racephoto_cart', JSON.stringify(items));
        }
    }, [items, isInitialized]);

    // AddItem can receive either:
    // 1. Full item object with id, variant, price, etc
    // 2. Photo object + variant number (legacy)
    const addItem = (itemOrPhoto, variant = null) => {
        setItems(prev => {
            let newItem;

            // Check if it's already a complete cart item
            if (itemOrPhoto.id && itemOrPhoto.variant !== undefined) {
                // New format: complete item object from ClassCatalog
                newItem = {
                    photoId: itemOrPhoto.id,
                    variant: itemOrPhoto.variant,
                    price: parseFloat(itemOrPhoto.price) || 0,
                    photoUrl: itemOrPhoto.url || itemOrPhoto.photoUrl,
                    startNo: itemOrPhoto.startNo,
                    eventName: itemOrPhoto.eventName || 'Unknown Event',
                    className: itemOrPhoto.className,
                    recapCount: itemOrPhoto.recapCount || 1
                };
            } else {
                // Legacy format: photo object + variant number
                const photoId = itemOrPhoto._id || itemOrPhoto.id;
                newItem = {
                    photoId: photoId,
                    variant: variant || 1,
                    price: parseFloat(itemOrPhoto.price) || 0,
                    photoUrl: itemOrPhoto.url || itemOrPhoto.photoUrl,
                    startNo: itemOrPhoto.startNo || itemOrPhoto.start_no,
                    eventName: itemOrPhoto.eventId?.name || itemOrPhoto.eventName || 'Unknown Event',
                    className: itemOrPhoto.class || itemOrPhoto.className
                };
            }

            // Check if item already exists
            const exists = prev.find(item =>
                item.photoId === newItem.photoId && item.variant === newItem.variant
            );

            if (exists) {
                console.log('Item already in cart:', newItem);
                return prev;
            }

            console.log('Adding to cart:', newItem);
            return [...prev, newItem];
        });
    };

    const removeItem = (photoId, variant) => {
        setItems(prev => prev.filter(item =>
            !(item.photoId === photoId && item.variant === variant)
        ));
    };

    const clearCart = () => {
        setItems([]);
        localStorage.removeItem('racephoto_cart');
    };

    const getTotal = () => {
        return items.reduce((sum, item) => sum + (parseFloat(item.price) || 0), 0);
    };

    const getCount = () => items.length;

    const isInCart = (photoId, variant) => {
        return items.some(item =>
            item.photoId === photoId && item.variant === variant
        );
    };

    return (
        <CartContext.Provider value={{
            items,
            addItem,
            removeItem,
            clearCart,
            getTotal,
            getCount,
            isInCart
        }}>
            {children}
        </CartContext.Provider>
    );
};
