import { useState, useMemo, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { getClassPhotos, getPhoto, getEvents } from '../services/api';

export default function ClassCatalog() {
    const { eventId, className } = useParams();
    const [photos, setPhotos] = useState([]);
    const [event, setEvent] = useState(null);
    const [brand, setBrand] = useState({});
    const [loading, setLoading] = useState(true);
    const [searchNo, setSearchNo] = useState('');
    const [selectedPhoto, setSelectedPhoto] = useState(null);
    const [selectedVariantIndex, setSelectedVariantIndex] = useState(0);
    const [loadingDetail, setLoadingDetail] = useState(false);
    const { items, addItem, getCount, getTotal } = useCart();

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [photosRes, eventsRes] = await Promise.all([
                    getClassPhotos(eventId, className),
                    getEvents()
                ]);
                setPhotos(photosRes.data.photos || []);
                setEvent(photosRes.data.event || null);
                setBrand(eventsRes.data.brand || {});
                if (typeof window !== 'undefined') {
                    localStorage.setItem('racephoto_last_catalog', window.location.pathname);
                }
            } catch (error) {
                console.error('Error fetching photos:', error);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [eventId, className]);

    const filteredPhotos = useMemo(() => {
        return photos.filter(p => {
            const startNo = p.start_no || p.startNo || '';
            return searchNo === '' || startNo.toString().includes(searchNo);
        });
    }, [searchNo, photos]);

    const openPhotoDetail = async (photo) => {
        setLoadingDetail(true);
        setSelectedPhoto(photo);
        setSelectedVariantIndex(0);
        try {
            // Fetch full photo details with recaps
            const res = await getPhoto(photo.id || photo._id);
            setSelectedPhoto(res.data);
        } catch (error) {
            console.error('Error fetching photo details:', error);
        } finally {
            setLoadingDetail(false);
        }
    };

    const closePhotoDetail = () => {
        setSelectedPhoto(null);
        setSelectedVariantIndex(0);
    };

    // Get variants (recaps only - these are the purchasable items)
    const getVariants = (photo) => {
        if (!photo.recaps || photo.recaps.length === 0) return [];
        return photo.recaps.map((recap, idx) => ({
            id: recap.id,
            variantNumber: recap.variant_number || idx + 1,
            url: recap.url
        }));
    };

    const addToCart = (e, photo, variantNumber) => {
        if (e) e.stopPropagation();

        const variants = getVariants(photo);
        const variant = variants.find(v => v.variantNumber === variantNumber);
        if (!variant) {
            alert('Varian tidak ditemukan');
            return;
        }

        // Check if this variant already in cart
        const photoId = photo.id || photo._id;
        const alreadyInCart = items.some(
            item => item.photoId === photoId && item.variant === variantNumber
        );
        if (alreadyInCart) {
            alert(`Varian ${variantNumber} sudah ada di keranjang`);
            return;
        }

        addItem({
            id: photoId,
            url: variant.url, // Use the recap/variant URL for the purchased image
            startNo: photo.start_no || photo.startNo,
            price: photo.price,
            className: decodeURIComponent(className),
            eventName: event?.name || '',
            variant: variantNumber,
            recapCount: variants.length
        });
    };

    const getCountInCart = (photoId) => items.filter(item => item.photoId === photoId).length;
    const isVariantInCart = (photoId, variantNumber) => items.some(item => item.photoId === photoId && item.variant === variantNumber);

    if (loading) {
        return (
            <div style={{
                minHeight: '100vh',
                background: 'black',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
                <div className="spinner"></div>
            </div>
        );
    }

    return (
        <div style={{ minHeight: '100vh', background: 'black', color: 'white' }}>
            {/* Navbar */}
            <nav style={{
                position: 'fixed',
                top: 0,
                left: 0,
                right: 0,
                zIndex: 80,
                background: 'linear-gradient(to bottom, rgba(0,0,0,0.95), rgba(0,0,0,0.9))',
                backdropFilter: 'blur(12px)',
                borderBottom: '1px solid rgba(255,255,255,0.05)'
            }}>
                <div style={{
                    maxWidth: '1280px',
                    margin: '0 auto',
                    padding: '0 1rem',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    height: '5rem'
                }}>
                    <Link to="/" style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.75rem',
                        color: 'white',
                        textDecoration: 'none'
                    }}>
                        {brand?.logo_url || brand?.siteLogo ? (
                            <img
                                src={`${import.meta.env.VITE_API_URL || 'http://localhost:5000'}${brand.logo_url || brand.siteLogo}`}
                                alt={brand?.site_name || brand?.siteName || 'RacePhoto'}
                                style={{
                                    height: '40px',
                                    width: 'auto',
                                    maxWidth: '160px',
                                    objectFit: 'contain'
                                }}
                            />
                        ) : (
                            <>
                                <div style={{
                                    background: '#39FF14',
                                    padding: '0.375rem',
                                    borderRadius: '0.5rem',
                                    fontSize: '1.125rem'
                                }}>
                                    📷
                                </div>
                                <span style={{
                                    fontSize: '1.25rem',
                                    fontWeight: 900,
                                    fontFamily: "'Archivo Black', sans-serif"
                                }}>
                                    {brand?.site_name || brand?.siteName || 'GEEZPLAY'}
                                </span>
                            </>
                        )}
                    </Link>
                    <Link to="/cart" style={{
                        position: 'relative',
                        padding: '0.625rem',
                        fontSize: '1.25rem',
                        color: 'white',
                        textDecoration: 'none'
                    }}>
                        🛒
                        {getCount() > 0 && (
                            <span style={{
                                position: 'absolute',
                                top: 0,
                                right: 0,
                                background: '#39FF14',
                                color: 'black',
                                fontSize: '10px',
                                fontWeight: 900,
                                width: '20px',
                                height: '20px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                borderRadius: '50%'
                            }}>
                                {getCount()}
                            </span>
                        )}
                    </Link>
                </div>
            </nav>

            {/* Photo Detail Modal */}
            {selectedPhoto && (
                <div
                    onClick={closePhotoDetail}
                    style={{
                        position: 'fixed',
                        inset: 0,
                        background: 'rgba(0,0,0,0.95)',
                        zIndex: 100,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        padding: '1rem'
                    }}
                >
                    <button
                        onClick={closePhotoDetail}
                        style={{
                            position: 'absolute',
                            top: '1rem',
                            right: '1rem',
                            background: 'transparent',
                            border: 'none',
                            color: 'rgba(255,255,255,0.5)',
                            fontSize: '2rem',
                            cursor: 'pointer'
                        }}
                    >
                        ✕
                    </button>

                    <div
                        onClick={(e) => e.stopPropagation()}
                        style={{
                            maxWidth: '900px',
                            width: '100%',
                            background: '#0a0a0a',
                            borderRadius: '24px',
                            overflow: 'hidden',
                            border: '1px solid rgba(255,255,255,0.1)',
                            maxHeight: '90vh',
                            overflowY: 'auto'
                        }}
                    >
                        {loadingDetail ? (
                            <div style={{ padding: '4rem', textAlign: 'center' }}>
                                <div className="spinner"></div>
                            </div>
                        ) : (
                            <>
                                {/* Main Preview Image (Photo utama - hanya preview) */}
                                <div style={{ position: 'relative', background: '#000' }}>
                                    <img
                                        src={selectedPhoto.photoUrl || selectedPhoto.url}
                                        alt={`Photo #${selectedPhoto.start_no || selectedPhoto.startNo}`}
                                        style={{
                                            width: '100%',
                                            maxHeight: '50vh',
                                            objectFit: 'contain'
                                        }}
                                    />
                                    <div style={{
                                        position: 'absolute',
                                        top: '1rem',
                                        left: '1rem',
                                        background: 'rgba(0,0,0,0.8)',
                                        padding: '0.5rem 1rem',
                                        borderRadius: '8px',
                                        fontSize: '0.75rem',
                                        color: 'rgba(255,255,255,0.7)'
                                    }}>
                                        📷 PREVIEW
                                    </div>
                                </div>

                                {/* Info Section */}
                                <div style={{ padding: '1.5rem' }}>
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
                                        <div>
                                            <p style={{
                                                fontSize: '10px',
                                                color: 'rgba(255,255,255,0.4)',
                                                fontWeight: 900,
                                                textTransform: 'uppercase',
                                                letterSpacing: '0.1em'
                                            }}>
                                                Nomor Start
                                            </p>
                                            <p style={{
                                                fontSize: '2rem',
                                                fontWeight: 900,
                                                fontStyle: 'italic'
                                            }}>
                                                #{selectedPhoto.start_no || selectedPhoto.startNo}
                                            </p>
                                        </div>
                                        <div style={{ textAlign: 'right' }}>
                                            <p style={{
                                                fontSize: '10px',
                                                color: 'rgba(255,255,255,0.4)',
                                                fontWeight: 900,
                                                textTransform: 'uppercase'
                                            }}>
                                                Harga Per Varian
                                            </p>
                                            <p style={{
                                                fontSize: '1.5rem',
                                                fontWeight: 900,
                                                color: '#39FF14'
                                            }}>
                                                Rp {(selectedPhoto.price || 0).toLocaleString()}
                                            </p>
                                        </div>
                                    </div>

                                    {/* Variants Section */}
                                    {(() => {
                                        const variants = getVariants(selectedPhoto);
                                        if (variants.length === 0) {
                                            return (
                                                <div style={{
                                                    background: 'rgba(255,165,0,0.1)',
                                                    border: '1px solid rgba(255,165,0,0.3)',
                                                    borderRadius: '12px',
                                                    padding: '1.5rem',
                                                    textAlign: 'center'
                                                }}>
                                                    <p style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>📷</p>
                                                    <p style={{ color: 'rgba(255,255,255,0.7)', fontWeight: 600 }}>
                                                        Varian foto belum tersedia
                                                    </p>
                                                    <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.875rem', marginTop: '0.25rem' }}>
                                                        Silakan hubungi admin untuk upload varian
                                                    </p>
                                                </div>
                                            );
                                        }

                                        return (
                                            <>
                                                <div style={{
                                                    background: 'rgba(57,255,20,0.1)',
                                                    border: '1px solid rgba(57,255,20,0.2)',
                                                    borderRadius: '12px',
                                                    padding: '1rem',
                                                    marginBottom: '1.5rem'
                                                }}>
                                                    <p style={{ fontSize: '0.875rem', color: 'rgba(255,255,255,0.7)' }}>
                                                        📷 <strong style={{ color: '#39FF14' }}>{variants.length}</strong> varian foto tersedia
                                                    </p>
                                                    <p style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.4)', marginTop: '0.25rem' }}>
                                                        Pilih varian yang ingin dibeli, setiap varian dijual terpisah
                                                    </p>
                                                </div>

                                                {/* Variant Number Buttons */}
                                                <p style={{
                                                    fontSize: '10px',
                                                    color: 'rgba(255,255,255,0.4)',
                                                    fontWeight: 900,
                                                    textTransform: 'uppercase',
                                                    letterSpacing: '0.1em',
                                                    marginBottom: '0.75rem'
                                                }}>
                                                    Pilih Varian
                                                </p>
                                                <div style={{
                                                    display: 'flex',
                                                    flexWrap: 'wrap',
                                                    gap: '0.75rem',
                                                    marginBottom: '1.5rem'
                                                }}>
                                                    {variants.map((variant, idx) => {
                                                        const photoId = selectedPhoto.id || selectedPhoto._id;
                                                        const inCart = isVariantInCart(photoId, variant.variantNumber);
                                                        const isSelected = selectedVariantIndex === idx;

                                                        return (
                                                            <button
                                                                key={variant.id}
                                                                onClick={() => setSelectedVariantIndex(idx)}
                                                                style={{
                                                                    padding: '1rem 1.5rem',
                                                                    borderRadius: '12px',
                                                                    cursor: 'pointer',
                                                                    fontWeight: 900,
                                                                    fontSize: '1rem',
                                                                    border: isSelected ? '3px solid #39FF14' : '2px solid rgba(255,255,255,0.2)',
                                                                    background: inCart ? 'rgba(57,255,20,0.2)' : isSelected ? 'rgba(57,255,20,0.1)' : 'rgba(255,255,255,0.05)',
                                                                    color: inCart ? '#39FF14' : isSelected ? '#39FF14' : 'white',
                                                                    boxShadow: isSelected ? '0 0 20px rgba(57,255,20,0.3)' : 'none',
                                                                    transition: 'all 0.2s'
                                                                }}
                                                            >
                                                                {inCart ? '✓ ' : ''}Varian {variant.variantNumber}
                                                            </button>
                                                        );
                                                    })}
                                                </div>

                                                {/* Add Selected Variant to Cart Button */}
                                                {(() => {
                                                    const selectedVariant = variants[selectedVariantIndex];
                                                    if (!selectedVariant) return null;

                                                    const photoId = selectedPhoto.id || selectedPhoto._id;
                                                    const inCart = isVariantInCart(photoId, selectedVariant.variantNumber);

                                                    return (
                                                        <button
                                                            onClick={(e) => addToCart(e, selectedPhoto, selectedVariant.variantNumber)}
                                                            disabled={inCart}
                                                            style={{
                                                                width: '100%',
                                                                padding: '1rem',
                                                                borderRadius: '12px',
                                                                border: 'none',
                                                                fontWeight: 900,
                                                                fontSize: '1rem',
                                                                textTransform: 'uppercase',
                                                                cursor: inCart ? 'not-allowed' : 'pointer',
                                                                background: inCart ? 'rgba(57,255,20,0.3)' : '#39FF14',
                                                                color: inCart ? 'rgba(255,255,255,0.7)' : 'black',
                                                                boxShadow: inCart ? 'none' : '0 15px 30px rgba(57,255,20,0.3)'
                                                            }}
                                                        >
                                                            {inCart
                                                                ? `✓ Varian ${selectedVariant.variantNumber} Sudah di Keranjang`
                                                                : `🛒 Tambah Varian ${selectedVariant.variantNumber} - Rp ${(selectedPhoto.price || 0).toLocaleString()}`
                                                            }
                                                        </button>
                                                    );
                                                })()}
                                            </>
                                        );
                                    })()}
                                </div>
                            </>
                        )}
                    </div>
                </div>
            )}

            {/* Content */}
            <div style={{ paddingTop: '6rem', paddingBottom: '10rem', maxWidth: '1280px', margin: '0 auto', padding: '6rem 1rem 10rem' }}>
                {/* Header */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
                    <Link
                        to={`/event/${eventId}`}
                        style={{
                            background: 'rgba(255,255,255,0.05)',
                            padding: '0.625rem',
                            borderRadius: '12px',
                            border: '1px solid rgba(255,255,255,0.1)',
                            color: 'white',
                            textDecoration: 'none'
                        }}
                    >
                        ◀
                    </Link>
                    <div>
                        <h2 style={{
                            fontSize: '1.5rem',
                            fontWeight: 900,
                            textTransform: 'uppercase',
                            fontStyle: 'italic'
                        }}>
                            {decodeURIComponent(className)}
                        </h2>
                        <p style={{ color: '#39FF14', fontSize: '0.75rem', fontWeight: 700, textTransform: 'uppercase' }}>
                            {event?.name || 'Katalog Foto'}
                        </p>
                    </div>
                </div>

                {/* Search */}
                <div style={{ marginBottom: '2rem', maxWidth: '400px' }}>
                    <div style={{ position: 'relative' }}>
                        <input
                            type="text"
                            inputMode="numeric"
                            placeholder="Cari Nomor Start (Contoh: 88)"
                            value={searchNo}
                            onChange={(e) => setSearchNo(e.target.value)}
                            style={{
                                width: '100%',
                                background: '#0a0a0a',
                                border: '1px solid rgba(255,255,255,0.1)',
                                borderRadius: '16px',
                                padding: '1rem 1rem 1rem 3rem',
                                color: 'white',
                                fontSize: '1rem',
                                boxSizing: 'border-box'
                            }}
                        />
                        <span style={{
                            position: 'absolute',
                            left: '1rem',
                            top: '50%',
                            transform: 'translateY(-50%)',
                            color: 'rgba(255,255,255,0.3)'
                        }}>
                            🔍
                        </span>
                    </div>
                </div>

                {/* Photo Grid - Only Main Photo as Preview */}
                <div style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))',
                    gap: '1rem'
                }}>
                    {filteredPhotos.map(photo => {
                        const photoId = photo.id || photo._id;
                        const countInCart = getCountInCart(photoId);
                        const recapCount = photo.recapCount || photo.recap_count || 0;

                        return (
                            <div
                                key={photoId}
                                onClick={() => openPhotoDetail(photo)}
                                style={{
                                    position: 'relative',
                                    background: '#0a0a0a',
                                    borderRadius: '16px',
                                    overflow: 'hidden',
                                    cursor: 'pointer',
                                    border: countInCart > 0 ? '2px solid #39FF14' : '1px solid rgba(255,255,255,0.05)',
                                    boxShadow: countInCart > 0 ? '0 0 20px rgba(57,255,20,0.3)' : 'none',
                                    transition: 'all 0.3s'
                                }}
                            >
                                {/* Main Photo Preview Only */}
                                <div style={{ position: 'relative', aspectRatio: '3/4', overflow: 'hidden' }}>
                                    <img
                                        src={photo.photoUrl || photo.url}
                                        alt={`Start #${photo.start_no || photo.startNo}`}
                                        loading="lazy"
                                        style={{
                                            width: '100%',
                                            height: '100%',
                                            objectFit: 'cover'
                                        }}
                                        onError={(e) => { e.target.src = '/placeholder.jpg'; }}
                                    />

                                    {/* Start No Badge */}
                                    <div style={{ position: 'absolute', bottom: '0.75rem', left: '0.75rem' }}>
                                        <span style={{
                                            background: 'rgba(0,0,0,0.8)',
                                            color: 'white',
                                            fontSize: '10px',
                                            fontWeight: 900,
                                            padding: '0.25rem 0.5rem',
                                            borderRadius: '999px',
                                            backdropFilter: 'blur(4px)'
                                        }}>
                                            #{photo.start_no || photo.startNo}
                                        </span>
                                    </div>

                                    {/* Variants Count Badge */}
                                    {recapCount > 0 && (
                                        <div style={{ position: 'absolute', top: '0.75rem', left: '0.75rem' }}>
                                            <span style={{
                                                background: '#39FF14',
                                                color: 'black',
                                                fontSize: '9px',
                                                fontWeight: 900,
                                                padding: '0.25rem 0.5rem',
                                                borderRadius: '4px'
                                            }}>
                                                {recapCount} VARIAN
                                            </span>
                                        </div>
                                    )}

                                    {/* No Variants Warning */}
                                    {recapCount === 0 && (
                                        <div style={{ position: 'absolute', top: '0.75rem', left: '0.75rem' }}>
                                            <span style={{
                                                background: 'rgba(255,165,0,0.9)',
                                                color: 'black',
                                                fontSize: '8px',
                                                fontWeight: 700,
                                                padding: '0.25rem 0.5rem',
                                                borderRadius: '4px'
                                            }}>
                                                PREVIEW
                                            </span>
                                        </div>
                                    )}

                                    {/* Cart Count Badge */}
                                    {countInCart > 0 && (
                                        <div style={{ position: 'absolute', top: '0.75rem', right: '0.75rem' }}>
                                            <div style={{
                                                background: '#39FF14',
                                                color: 'black',
                                                width: '28px',
                                                height: '28px',
                                                borderRadius: '50%',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontWeight: 900,
                                                fontSize: '11px',
                                                border: '2px solid black'
                                            }}>
                                                {countInCart}
                                            </div>
                                        </div>
                                    )}
                                </div>

                                {/* Price & View Button */}
                                <div style={{
                                    padding: '1rem',
                                    borderTop: '1px solid rgba(255,255,255,0.05)',
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    alignItems: 'center'
                                }}>
                                    <p style={{ color: '#39FF14', fontWeight: 900, fontSize: '1rem' }}>
                                        Rp {(photo.price || 0).toLocaleString()}
                                    </p>
                                    <span style={{
                                        padding: '0.5rem 0.75rem',
                                        borderRadius: '8px',
                                        background: recapCount > 0 ? 'rgba(57,255,20,0.2)' : 'rgba(255,255,255,0.1)',
                                        color: recapCount > 0 ? '#39FF14' : 'rgba(255,255,255,0.5)',
                                        fontWeight: 700,
                                        fontSize: '0.75rem'
                                    }}>
                                        {recapCount > 0 ? 'Lihat Varian' : 'Preview'}
                                    </span>
                                </div>
                            </div>
                        );
                    })}
                </div>

                {filteredPhotos.length === 0 && (
                    <div style={{ textAlign: 'center', padding: '3rem', color: 'rgba(255,255,255,0.4)' }}>
                        <span style={{ fontSize: '3rem', display: 'block', marginBottom: '1rem' }}>📷</span>
                        <p>Tidak ada foto ditemukan</p>
                    </div>
                )}
            </div>

            {/* Bottom Checkout Bar */}
            {getCount() > 0 && (
                <div style={{
                    position: 'fixed',
                    bottom: 0,
                    left: 0,
                    right: 0,
                    padding: '1rem',
                    paddingTop: '4rem',
                    background: 'linear-gradient(to top, black, rgba(0,0,0,0.95), transparent)',
                    zIndex: 70
                }}>
                    <div style={{ maxWidth: '600px', margin: '0 auto' }}>
                        <Link
                            to="/cart"
                            style={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                width: '100%',
                                background: '#39FF14',
                                color: 'black',
                                fontWeight: 900,
                                textTransform: 'uppercase',
                                padding: '1rem 1.5rem',
                                borderRadius: '16px',
                                textDecoration: 'none',
                                boxShadow: '0 20px 40px rgba(57,255,20,0.3)'
                            }}
                        >
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                                <div style={{
                                    background: 'black',
                                    color: '#39FF14',
                                    width: '40px',
                                    height: '40px',
                                    borderRadius: '50%',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    fontSize: '0.75rem',
                                    fontWeight: 900
                                }}>
                                    {getCount()}
                                </div>
                                <span style={{ fontStyle: 'italic' }}>Lanjut Checkout</span>
                            </div>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                                <span style={{ fontStyle: 'italic' }}>Rp {getTotal().toLocaleString()}</span>
                                →
                            </div>
                        </Link>
                    </div>
                </div>
            )}
        </div>
    );
}
