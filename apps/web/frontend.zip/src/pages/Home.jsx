import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { getEvents, getUpcomingEvents } from '../services/api';
import { ShoppingCart, User, Menu, X, Camera, Calendar, Info, Briefcase, Home as HomeIcon, Zap } from 'lucide-react';

const CATEGORY_LABELS = {
    development: 'Development By',
    sponsor: 'Sponsor Utama',
    media: 'Media Partner',
};

const RACE_CATEGORY_LABELS = {
    drag: 'DRAG RACE',
    drift: 'DRIFT',
    rally: 'RALLY',
    touring: 'TOURING',
    moto: 'MOTO GP',
    road_race: 'ROAD RACE'
};

export default function Home() {
    const [data, setData] = useState({ events: [], sponsors: {}, photographers: [], brand: {} });
    const [upcomingEvents, setUpcomingEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const [searchData, setSearchData] = useState({ event: '', location: '' });
    const [countdowns, setCountdowns] = useState({});
    const [selectedEvent, setSelectedEvent] = useState(null);
    const [zoomLevel, setZoomLevel] = useState(1);
    const [isScrolled, setIsScrolled] = useState(false);
    const { getCount } = useCart();

    // Scroll detection for navbar
    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 20);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [eventsRes, upcomingRes] = await Promise.all([
                    getEvents(),
                    getUpcomingEvents()
                ]);
                setData(eventsRes.data);
                setUpcomingEvents(upcomingRes.data?.events || []);
            } catch (error) {
                console.error('Error fetching events:', error);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    // Countdown timer effect for all upcoming events
    useEffect(() => {
        if (upcomingEvents.length === 0) return;

        const updateCountdowns = () => {
            const now = new Date();
            const newCountdowns = {};

            upcomingEvents.forEach(event => {
                const targetDate = new Date(event.start_time || event.startTime);
                const diff = targetDate - now;

                if (diff <= 0) {
                    newCountdowns[event.id] = { days: 0, hours: 0, minutes: 0, seconds: 0 };
                } else {
                    newCountdowns[event.id] = {
                        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
                        hours: Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
                        minutes: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
                        seconds: Math.floor((diff % (1000 * 60)) / 1000)
                    };
                }
            });

            setCountdowns(newCountdowns);
        };

        updateCountdowns();
        const interval = setInterval(updateCountdowns, 1000);
        return () => clearInterval(interval);
    }, [upcomingEvents]);

    const handleSearch = (e) => {
        e.preventDefault();
        if (data.events.length > 0) {
            window.location.href = `/event/${data.events[0]._id || data.events[0].id}`;
        }
    };

    const handleOpenLightbox = (event, imageUrl) => {
        setSelectedEvent({ ...event, fullImageUrl: imageUrl });
        setZoomLevel(1);
    };

    const handleCloseLightbox = () => {
        setSelectedEvent(null);
        setZoomLevel(1);
    };

    const handleDownload = async () => {
        if (!selectedEvent?.fullImageUrl) return;
        try {
            const response = await fetch(selectedEvent.fullImageUrl);
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `event-${selectedEvent.title || selectedEvent.name || 'image'}.jpg`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        } catch (error) {
            console.error('Download error:', error);
            window.open(selectedEvent.fullImageUrl, '_blank');
        }
    };

    const handleZoomIn = () => setZoomLevel(prev => Math.min(prev + 0.5, 3));
    const handleZoomOut = () => setZoomLevel(prev => Math.max(prev - 0.5, 0.5));
    const handleResetZoom = () => setZoomLevel(1);

    if (loading) {
        return (
            <div className="loading-screen">
                <div className="spinner"></div>
                <p style={{ color: 'rgba(255,255,255,0.7)' }}>Loading...</p>
            </div>
        );
    }

    const { events, sponsors, photographers, brand } = data;
    const locations = [...new Set(events.map(e => e.location).filter(Boolean))];

    return (
        <div className="app-wrapper">
            {/* MODERN NAVBAR - Gaming/Esports Style */}
            <nav style={{
                position: 'fixed',
                top: 0,
                left: 0,
                right: 0,
                zIndex: 100,
                background: isScrolled ? 'rgba(0,0,0,0.85)' : 'transparent',
                backdropFilter: isScrolled ? 'blur(12px)' : 'none',
                borderBottom: isScrolled ? '1px solid rgba(255,255,255,0.05)' : 'none',
                transition: 'all 0.3s ease'
            }}>
                <div style={{
                    maxWidth: '1280px',
                    margin: '0 auto',
                    padding: '0 1rem',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    height: '5rem'
                }}>
                    {/* Logo with Skew Effect */}
                    <Link to="/" style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.75rem',
                        color: 'white',
                        textDecoration: 'none',
                        position: 'relative'
                    }}>
                        {brand?.logo_url || brand?.siteLogo ? (
                            <img
                                src={`${import.meta.env.VITE_API_URL || 'http://localhost:5000'}${brand.logo_url || brand.siteLogo}`}
                                alt={brand?.site_name || brand?.siteName || 'RacePhoto'}
                                style={{
                                    height: '45px',
                                    width: 'auto',
                                    maxWidth: '180px',
                                    objectFit: 'contain'
                                }}
                            />
                        ) : (
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', position: 'relative' }}>
                                {/* Pulse Decoration */}
                                <div style={{
                                    position: 'absolute',
                                    left: '-10px',
                                    width: '8px',
                                    height: '8px',
                                    background: '#39FF14',
                                    borderRadius: '50%',
                                    animation: 'pulse 2s infinite',
                                    boxShadow: '0 0 10px #39FF14'
                                }}></div>
                                <span style={{
                                    fontSize: '1.5rem',
                                    fontWeight: 900,
                                    fontStyle: 'italic',
                                    letterSpacing: '-0.02em',
                                    fontFamily: "'Archivo Black', sans-serif",
                                    transform: 'skewX(-12deg)',
                                    display: 'inline-block',
                                    textShadow: '0 0 20px rgba(168,85,247,0.5), 0 0 40px rgba(57,255,20,0.3)'
                                }}>
                                    <span style={{ color: '#a855f7' }}>GEEZ</span>
                                    <span style={{ color: '#39FF14' }}> PLAY</span>
                                </span>
                            </div>
                        )}
                    </Link>

                    {/* Desktop Navigation */}
                    <div className="desktop-nav" style={{
                        display: 'none',
                        alignItems: 'center',
                        gap: '0.25rem'
                    }}>
                        {[
                            { href: '#', label: 'HOME', icon: HomeIcon },
                            { href: '#upcoming', label: 'UPCOMING', icon: Calendar },
                            { href: '#events', label: 'EVENT', icon: Camera },
                            { href: '#photographers', label: 'FOTOGRAFER', icon: User },
                            { href: '#workflow', label: 'CARA KERJA', icon: Info },
                            { href: '#booking', label: 'BOOKING', icon: Briefcase }
                        ].map((item) => (
                            <a
                                key={item.label}
                                href={item.href}
                                style={{
                                    color: 'rgba(209,213,219,1)',
                                    padding: '0.5rem 1rem',
                                    fontSize: '0.75rem',
                                    fontWeight: 600,
                                    letterSpacing: '0.05em',
                                    textDecoration: 'none',
                                    position: 'relative',
                                    transition: 'color 0.3s'
                                }}
                                className="nav-link-modern"
                            >
                                {item.label}
                            </a>
                        ))}
                    </div>

                    {/* Right Section - Desktop */}
                    <div className="desktop-actions" style={{
                        display: 'none',
                        alignItems: 'center',
                        gap: '0.75rem'
                    }}>
                        {/* Cart */}
                        <Link to="/cart" style={{
                            position: 'relative',
                            padding: '0.625rem',
                            borderRadius: '0.5rem',
                            color: 'rgba(209,213,219,1)',
                            transition: 'all 0.3s',
                            display: 'flex',
                            alignItems: 'center'
                        }}>
                            <ShoppingCart size={22} />
                            {getCount() > 0 && (
                                <span style={{
                                    position: 'absolute',
                                    top: '2px',
                                    right: '2px',
                                    background: '#39FF14',
                                    color: 'black',
                                    fontSize: '10px',
                                    fontWeight: 900,
                                    width: '1.25rem',
                                    height: '1.25rem',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    borderRadius: '50%'
                                }}>
                                    {getCount()}
                                </span>
                            )}
                        </Link>

                        {/* Login Button with Glow */}
                        <Link to="/login" style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '0.5rem',
                            background: '#22c55e',
                            color: 'black',
                            padding: '0.625rem 1.25rem',
                            borderRadius: '0.5rem',
                            fontWeight: 700,
                            fontSize: '0.75rem',
                            textTransform: 'uppercase',
                            letterSpacing: '0.05em',
                            transition: 'all 0.3s',
                            textDecoration: 'none',
                            boxShadow: '0 0 20px rgba(34,197,94,0.4)'
                        }}>
                            <User size={16} />
                            LOGIN
                        </Link>
                    </div>

                    {/* Mobile Menu Button */}
                    <button
                        style={{
                            padding: '0.5rem',
                            color: 'white',
                            borderRadius: '0.5rem',
                            background: mobileMenuOpen ? 'rgba(255,255,255,0.1)' : 'transparent',
                            border: 'none',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            transition: 'all 0.3s'
                        }}
                        className="mobile-menu-btn"
                        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                    >
                        {mobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
                    </button>
                </div>

                {/* Mobile Menu Dropdown */}
                <div style={{
                    maxHeight: mobileMenuOpen ? '500px' : '0',
                    overflow: 'hidden',
                    transition: 'max-height 0.3s ease-in-out',
                    background: 'rgba(0,0,0,0.95)',
                    backdropFilter: 'blur(12px)',
                    borderTop: mobileMenuOpen ? '1px solid rgba(255,255,255,0.05)' : 'none'
                }} className="mobile-menu">
                    <div style={{ padding: '1rem' }}>
                        {[
                            { href: '#', label: 'HOME', icon: HomeIcon },
                            { href: '#upcoming', label: 'UPCOMING', icon: Calendar },
                            { href: '#events', label: 'EVENT', icon: Camera },
                            { href: '#photographers', label: 'FOTOGRAFER', icon: User },
                            { href: '#workflow', label: 'CARA KERJA', icon: Info },
                            { href: '#booking', label: 'BOOKING', icon: Briefcase }
                        ].map((item) => {
                            const IconComponent = item.icon;
                            return (
                                <a
                                    key={item.label}
                                    href={item.href}
                                    onClick={() => setMobileMenuOpen(false)}
                                    style={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '0.75rem',
                                        color: 'rgba(209,213,219,1)',
                                        padding: '0.875rem 1rem',
                                        fontSize: '0.9rem',
                                        fontWeight: 500,
                                        textDecoration: 'none',
                                        borderRadius: '0.5rem',
                                        transition: 'all 0.2s'
                                    }}
                                >
                                    <IconComponent size={18} style={{ color: '#39FF14' }} />
                                    {item.label}
                                </a>
                            );
                        })}

                        {/* Cart - Mobile */}
                        <Link
                            to="/cart"
                            onClick={() => setMobileMenuOpen(false)}
                            style={{
                                display: 'flex',
                                alignItems: 'center',
                                gap: '0.75rem',
                                color: 'rgba(209,213,219,1)',
                                padding: '0.875rem 1rem',
                                fontSize: '0.9rem',
                                fontWeight: 500,
                                textDecoration: 'none',
                                borderRadius: '0.5rem'
                            }}
                        >
                            <ShoppingCart size={18} style={{ color: '#39FF14' }} />
                            KERANJANG
                            {getCount() > 0 && (
                                <span style={{
                                    background: '#39FF14',
                                    color: 'black',
                                    fontSize: '11px',
                                    fontWeight: 700,
                                    padding: '0.125rem 0.5rem',
                                    borderRadius: '9999px',
                                    marginLeft: 'auto'
                                }}>
                                    {getCount()}
                                </span>
                            )}
                        </Link>

                        {/* Login Button - Mobile */}
                        <Link
                            to="/login"
                            onClick={() => setMobileMenuOpen(false)}
                            style={{
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '0.5rem',
                                background: '#22c55e',
                                color: 'black',
                                padding: '0.875rem',
                                borderRadius: '0.5rem',
                                fontWeight: 700,
                                fontSize: '0.875rem',
                                textTransform: 'uppercase',
                                textDecoration: 'none',
                                marginTop: '1rem',
                                boxShadow: '0 0 20px rgba(34,197,94,0.3)'
                            }}
                        >
                            <User size={18} />
                            LOGIN
                        </Link>
                    </div>
                </div>
            </nav>

            {/* CSS for Modern Navbar */}
            <style>{`
                @media (min-width: 1024px) {
                    .desktop-nav { display: flex !important; }
                    .desktop-actions { display: flex !important; }
                    .mobile-menu-btn { display: none !important; }
                    .mobile-menu { display: none !important; }
                }
                
                .nav-link-modern:hover {
                    color: white !important;
                }
                
                .nav-link-modern::after {
                    content: '';
                    position: absolute;
                    bottom: 0;
                    left: 50%;
                    width: 0;
                    height: 2px;
                    background: #39FF14;
                    transition: all 0.3s ease;
                    transform: translateX(-50%);
                }
                
                .nav-link-modern:hover::after {
                    width: 80%;
                }
                
                @keyframes pulse {
                    0%, 100% { opacity: 1; transform: scale(1); }
                    50% { opacity: 0.5; transform: scale(1.2); }
                }
            `}</style>

            {/* HERO SECTION */}
            <section style={{
                position: 'relative',
                minHeight: '100vh',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                overflow: 'hidden'
            }}>
                <div style={{ position: 'absolute', inset: 0 }}>
                    <div style={{
                        position: 'absolute',
                        inset: 0,
                        background: 'linear-gradient(to bottom, rgba(0,0,0,0.6), rgba(0,0,0,0.4), rgba(2,2,2,1))',
                        zIndex: 10
                    }}></div>
                    <img
                        src="https://images.unsplash.com/photo-1533130061792-64b345e4a833?auto=format&fit=crop&q=80&w=2000"
                        alt="Race Action"
                        style={{
                            width: '100%',
                            height: '100%',
                            objectFit: 'cover',
                            filter: 'grayscale(1)',
                            opacity: 0.5,
                            transform: 'scale(1.1)'
                        }}
                    />
                </div>
                <div style={{
                    position: 'relative',
                    zIndex: 20,
                    textAlign: 'center',
                    paddingTop: '5rem',
                    padding: '5rem 1rem',
                    maxWidth: '56rem'
                }}>
                    <h1 style={{
                        fontSize: 'clamp(2.5rem, 8vw, 5rem)',
                        fontWeight: 900,
                        fontStyle: 'italic',
                        letterSpacing: '-0.05em',
                        lineHeight: 1,
                        marginBottom: '1.5rem',
                        fontFamily: "'Archivo Black', sans-serif"
                    }}>
                        CAPTURE THE <span style={{ color: '#39FF14' }}>SPEED.</span>
                        <br />
                        OWN THE MOMENT.
                    </h1>
                    <p style={{
                        fontSize: 'clamp(0.875rem, 2vw, 1.25rem)',
                        color: 'rgba(255,255,255,0.7)',
                        maxWidth: '42rem',
                        margin: '0 auto 2.5rem'
                    }}>
                        Marketplace foto balapan terbesar untuk pembalap profesional dan hobi. Temukan fotomu dalam hitungan detik.
                    </p>
                </div>
                <div style={{
                    position: 'absolute',
                    bottom: '2.5rem',
                    left: '50%',
                    transform: 'translateX(-50%)',
                    color: '#39FF14',
                    fontSize: '1.5rem'
                }} className="animate-bounce-slow">
                    ▼
                </div>
            </section>

            {/* SEARCH SECTION */}
            <section style={{
                position: 'relative',
                zIndex: 50,
                marginTop: '-5rem',
                padding: '0 1rem'
            }}>
                <div style={{
                    maxWidth: '56rem',
                    margin: '0 auto',
                    background: '#0a0a0a',
                    padding: '1.5rem 2rem',
                    borderRadius: '1rem',
                    boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
                    borderTop: '4px solid #39FF14',
                    borderLeft: '1px solid rgba(255,255,255,0.1)',
                    borderRight: '1px solid rgba(255,255,255,0.1)',
                    borderBottom: '1px solid rgba(255,255,255,0.1)'
                }}>
                    <form onSubmit={handleSearch} style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                        gap: '1rem'
                    }}>
                        <div style={{ display: 'flex', flexDirection: 'column' }}>
                            <label className="input-label">NAMA EVENT</label>
                            <input
                                type="text"
                                placeholder="Cari event..."
                                value={searchData.event}
                                onChange={(e) => setSearchData({ ...searchData, event: e.target.value })}
                                className="input-field"
                            />
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column' }}>
                            <label className="input-label">LOKASI</label>
                            <select
                                value={searchData.location}
                                onChange={(e) => setSearchData({ ...searchData, location: e.target.value })}
                                className="input-field"
                            >
                                <option value="">Semua Lokasi</option>
                                {locations.map(loc => (
                                    <option key={loc} value={loc}>{loc}</option>
                                ))}
                            </select>
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
                            <button type="submit" className="btn-primary">
                                🔍 CARI SEKARANG
                            </button>
                        </div>
                    </form>
                </div>
            </section>

            {/* UPCOMING EVENTS SECTION - Geezplay Style */}
            <section id="upcoming" style={{
                padding: '5rem 0',
                background: '#050505',
                position: 'relative',
                overflow: 'hidden'
            }}>
                {/* Grid Pattern Background */}
                <div style={{
                    position: 'absolute',
                    inset: 0,
                    backgroundImage: 'linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px)',
                    backgroundSize: '50px 50px',
                    opacity: 0.5,
                    pointerEvents: 'none'
                }}></div>

                {/* Glow Effects */}
                <div style={{
                    position: 'absolute',
                    top: '20%',
                    left: '-10%',
                    width: '400px',
                    height: '400px',
                    background: 'radial-gradient(circle, rgba(0,240,255,0.08) 0%, transparent 70%)',
                    pointerEvents: 'none'
                }}></div>
                <div style={{
                    position: 'absolute',
                    bottom: '10%',
                    right: '-10%',
                    width: '400px',
                    height: '400px',
                    background: 'radial-gradient(circle, rgba(112,0,255,0.08) 0%, transparent 70%)',
                    pointerEvents: 'none'
                }}></div>

                <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 1rem', position: 'relative', zIndex: 10 }}>
                    {/* Section Header */}
                    <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
                        <h2 style={{
                            fontSize: 'clamp(2rem, 5vw, 3rem)',
                            fontWeight: 900,
                            textTransform: 'uppercase',
                            letterSpacing: '0.1em',
                            fontFamily: "'Orbitron', 'Rajdhani', sans-serif",
                            marginBottom: '1rem'
                        }}>
                            <span style={{ color: '#00F0FF' }}>UPCOMING</span>{' '}
                            <span style={{ color: 'white' }}>RACES</span>
                        </h2>
                        <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '1rem' }}>
                            Jadwal event balap yang akan datang
                        </p>
                    </div>

                    {/* Events Grid */}
                    {upcomingEvents.length > 0 ? (
                        <div style={{
                            display: 'grid',
                            gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 380px))',
                            gap: '1.5rem',
                            justifyContent: 'center'
                        }}>
                            {upcomingEvents.map(event => {
                                const countdown = countdowns[event.id] || { days: 0, hours: 0, minutes: 0, seconds: 0 };
                                const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:5000';
                                const imageUrl = event.imageUrl?.startsWith('http')
                                    ? event.imageUrl
                                    : event.imageUrl
                                        ? `${apiUrl}${event.imageUrl}`
                                        : 'https://images.unsplash.com/photo-1533130061792-64b345e4a833?auto=format&fit=crop&q=80&w=600';

                                return (
                                    <div key={event.id} style={{
                                        background: 'rgba(0,0,0,0.6)',
                                        backdropFilter: 'blur(10px)',
                                        borderRadius: '16px',
                                        overflow: 'hidden',
                                        border: '1px solid rgba(0,240,255,0.1)',
                                        transition: 'all 0.3s',
                                        position: 'relative'
                                    }}>
                                        {/* Image Container */}
                                        <div style={{ position: 'relative', height: '180px', overflow: 'hidden' }}>
                                            <img
                                                src={imageUrl}
                                                alt={event.title || event.name}
                                                style={{
                                                    width: '100%',
                                                    height: '100%',
                                                    objectFit: 'cover'
                                                }}
                                            />
                                            {/* Category Badge */}
                                            <div style={{
                                                position: 'absolute',
                                                top: '0.75rem',
                                                left: '0.75rem',
                                                background: 'rgba(0,240,255,0.9)',
                                                color: 'black',
                                                padding: '0.25rem 0.75rem',
                                                borderRadius: '4px',
                                                fontSize: '0.65rem',
                                                fontWeight: 900,
                                                letterSpacing: '0.1em',
                                                textTransform: 'uppercase'
                                            }}>
                                                {RACE_CATEGORY_LABELS[event.category] || event.categoryLabel || 'RACE'}
                                            </div>
                                            {/* Date Badge */}
                                            <div style={{
                                                position: 'absolute',
                                                top: '0.75rem',
                                                right: '0.75rem',
                                                background: 'rgba(112,0,255,0.9)',
                                                color: 'white',
                                                padding: '0.35rem 0.75rem',
                                                borderRadius: '6px',
                                                fontSize: '0.7rem',
                                                fontWeight: 700,
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '0.35rem'
                                            }}>
                                                🕐 {new Date(event.start_time || event.startTime).toLocaleDateString('id-ID', {
                                                    day: 'numeric',
                                                    month: 'short'
                                                })}
                                            </div>
                                            {/* Gradient Overlay */}
                                            <div style={{
                                                position: 'absolute',
                                                bottom: 0,
                                                left: 0,
                                                right: 0,
                                                height: '80px',
                                                background: 'linear-gradient(transparent, rgba(0,0,0,0.8))'
                                            }}></div>
                                        </div>

                                        {/* Content */}
                                        <div style={{ padding: '1.25rem' }}>
                                            {/* Title */}
                                            <h3 style={{
                                                fontSize: '1.125rem',
                                                fontWeight: 700,
                                                marginBottom: '0.75rem',
                                                lineHeight: 1.3,
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                                display: '-webkit-box',
                                                WebkitLineClamp: 2,
                                                WebkitBoxOrient: 'vertical'
                                            }}>
                                                {event.title || event.name}
                                            </h3>

                                            {/* Location */}
                                            <div style={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '0.5rem',
                                                fontSize: '0.8rem',
                                                color: 'rgba(255,255,255,0.6)',
                                                marginBottom: '1rem'
                                            }}>
                                                <span style={{ color: '#00F0FF' }}>📍</span>
                                                {event.location || 'TBA'}
                                            </div>

                                            {/* Countdown */}
                                            <div style={{
                                                display: 'flex',
                                                gap: '0.5rem',
                                                marginBottom: '1rem'
                                            }}>
                                                {[
                                                    { value: countdown.days, label: 'H' },
                                                    { value: countdown.hours, label: 'J' },
                                                    { value: countdown.minutes, label: 'M' },
                                                    { value: countdown.seconds, label: 'D' }
                                                ].map((item, idx) => (
                                                    <div key={idx} style={{
                                                        flex: 1,
                                                        background: 'rgba(0,240,255,0.05)',
                                                        border: '1px solid rgba(0,240,255,0.2)',
                                                        borderRadius: '8px',
                                                        padding: '0.5rem',
                                                        textAlign: 'center'
                                                    }}>
                                                        <div style={{
                                                            fontSize: '1.25rem',
                                                            fontWeight: 900,
                                                            color: '#00F0FF',
                                                            fontFamily: "'Orbitron', monospace"
                                                        }}>
                                                            {String(item.value).padStart(2, '0')}
                                                        </div>
                                                        <div style={{
                                                            fontSize: '0.55rem',
                                                            color: 'rgba(255,255,255,0.4)',
                                                            textTransform: 'uppercase'
                                                        }}>
                                                            {item.label}
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>

                                            {/* Action Buttons */}
                                            <div style={{ display: 'flex', gap: '0.75rem' }}>
                                                <button
                                                    onClick={() => handleOpenLightbox(event, imageUrl)}
                                                    style={{
                                                        flex: 1,
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        justifyContent: 'center',
                                                        gap: '0.5rem',
                                                        background: 'linear-gradient(135deg, #7000FF, #5000CC)',
                                                        color: 'white',
                                                        padding: '0.75rem',
                                                        borderRadius: '8px',
                                                        fontWeight: 700,
                                                        fontSize: '0.8rem',
                                                        border: 'none',
                                                        cursor: 'pointer',
                                                        textTransform: 'uppercase',
                                                        transition: 'all 0.3s'
                                                    }}
                                                >
                                                    🔍 Lihat Gambar
                                                </button>
                                                {event.external_link && (
                                                    <a
                                                        href={event.external_link}
                                                        target="_blank"
                                                        rel="noopener noreferrer"
                                                        style={{
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            justifyContent: 'center',
                                                            background: 'rgba(57,255,20,0.1)',
                                                            border: '1px solid rgba(57,255,20,0.3)',
                                                            color: '#39FF14',
                                                            padding: '0.75rem 1rem',
                                                            borderRadius: '8px',
                                                            fontSize: '0.8rem',
                                                            textDecoration: 'none'
                                                        }}
                                                    >
                                                        🔗
                                                    </a>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    ) : (
                        /* Empty State */
                        <div style={{
                            textAlign: 'center',
                            padding: '5rem 0',
                            color: 'rgba(255,255,255,0.3)'
                        }}>
                            <div style={{ fontSize: '5rem', marginBottom: '1rem', opacity: 0.3 }}>🏁</div>
                            <h3 style={{
                                fontSize: '1.5rem',
                                fontWeight: 700,
                                color: 'rgba(255,255,255,0.4)',
                                marginBottom: '0.5rem',
                                fontFamily: "'Orbitron', sans-serif"
                            }}>
                                No Upcoming Races
                            </h3>
                            <p style={{ fontSize: '0.9rem', color: 'rgba(255,255,255,0.3)' }}>
                                The engines are cooling down.
                            </p>
                        </div>
                    )}
                </div>
            </section>


            {/* EVENTS SECTION */}
            <section id="events" style={{ padding: '6rem 0' }}>
                <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 1rem' }}>
                    <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'flex-end',
                        marginBottom: '3rem'
                    }}>
                        <div>
                            <h2 style={{
                                fontSize: 'clamp(1.5rem, 4vw, 2.25rem)',
                                fontWeight: 900,
                                fontStyle: 'italic',
                                fontFamily: "'Archivo Black', sans-serif"
                            }}>
                                EVENT <span style={{ color: '#39FF14' }}>TERBARU</span>
                            </h2>
                            <div style={{ height: '4px', width: '5rem', background: '#39FF14', marginTop: '0.5rem' }}></div>
                        </div>
                        <a href="#events" style={{
                            fontSize: '0.75rem',
                            fontWeight: 700,
                            color: 'rgba(255,255,255,0.5)',
                            textDecoration: 'underline',
                            letterSpacing: '0.1em'
                        }}>
                            LIHAT SEMUA
                        </a>
                    </div>
                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
                        gap: '2rem'
                    }}>
                        {events.map(event => (
                            <Link
                                key={event._id || event.id}
                                to={`/event/${event._id || event.id}`}
                                className="card"
                            >
                                <div style={{ position: 'relative', height: '16rem', overflow: 'hidden' }}>
                                    <img
                                        src={event.imageUrl || event.image}
                                        alt={event.name}
                                        style={{
                                            width: '100%',
                                            height: '100%',
                                            objectFit: 'cover',
                                            transition: 'transform 0.5s'
                                        }}
                                    />
                                    <div style={{
                                        position: 'absolute',
                                        top: '1rem',
                                        left: '1rem',
                                        background: 'rgba(0,0,0,0.8)',
                                        padding: '0.25rem 0.75rem',
                                        fontSize: '10px',
                                        fontWeight: 700,
                                        letterSpacing: '-0.02em',
                                        border: '1px solid #39FF14',
                                        color: '#39FF14'
                                    }}>
                                        ROAD RACE
                                    </div>
                                </div>
                                <div style={{ padding: '1.5rem' }}>
                                    <h3 style={{
                                        fontSize: '1.25rem',
                                        fontWeight: 700,
                                        marginBottom: '0.5rem'
                                    }}>{event.name}</h3>
                                    <div style={{
                                        fontSize: '0.75rem',
                                        color: 'rgba(255,255,255,0.5)',
                                        marginBottom: '1rem'
                                    }}>
                                        📍 {event.location}
                                    </div>
                                    <div style={{
                                        display: 'flex',
                                        justifyContent: 'space-between',
                                        alignItems: 'center'
                                    }}>
                                        <span style={{
                                            fontSize: '10px',
                                            fontWeight: 700,
                                            color: 'rgba(255,255,255,0.4)',
                                            textTransform: 'uppercase'
                                        }}>
                                            {event.date}
                                        </span>
                                        <span style={{
                                            fontSize: '0.75rem',
                                            fontWeight: 700,
                                            color: '#39FF14'
                                        }}>
                                            LIHAT GALERI →
                                        </span>
                                    </div>
                                </div>
                            </Link>
                        ))}
                        {events.length === 0 && (
                            <div style={{
                                gridColumn: '1 / -1',
                                textAlign: 'center',
                                padding: '5rem 0',
                                color: 'rgba(255,255,255,0.3)'
                            }}>
                                <span style={{ fontSize: '3rem', display: 'block', marginBottom: '1rem', opacity: 0.5 }}>📷</span>
                                <p>Belum ada event tersedia</p>
                            </div>
                        )}
                    </div>
                </div>
            </section>

            {/* PHOTOGRAPHERS SECTION */}
            {photographers && photographers.length > 0 && (
                <section id="photographers" style={{ padding: '5rem 0', background: '#020202' }}>
                    <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 1rem' }}>
                        <h2 style={{
                            fontSize: 'clamp(1.5rem, 4vw, 2.25rem)',
                            fontWeight: 900,
                            fontStyle: 'italic',
                            textAlign: 'center',
                            marginBottom: '3rem',
                            color: '#39FF14',
                            fontFamily: "'Archivo Black', sans-serif"
                        }}>
                            FOTOGRAFER KAMI
                        </h2>
                        <div style={{ position: 'relative' }}>
                            <div id="photographer-scroll" className="scrollbar-hide" style={{
                                display: 'flex',
                                gap: '1rem',
                                overflowX: 'auto',
                                padding: '0.5rem 3rem',
                                scrollSnapType: 'x mandatory'
                            }}>
                                {photographers.map((photographer, index) => (
                                    <div key={photographer._id || photographer.id} style={{
                                        flexShrink: 0,
                                        width: '20rem',
                                        scrollSnapAlign: 'center'
                                    }}>
                                        <div
                                            style={{
                                                position: 'relative',
                                                overflow: 'hidden',
                                                borderRadius: '1rem',
                                                boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
                                                aspectRatio: '3/4',
                                                background: `linear-gradient(135deg, ${photographer.gradientFrom || photographer.gradient_from || '#1a1a1a'}, ${photographer.gradientTo || photographer.gradient_to || '#0a0a0a'})`
                                            }}
                                        >
                                            {(photographer.photoUrl || photographer.photo) && (
                                                <img
                                                    src={photographer.photoUrl || photographer.photo}
                                                    alt={photographer.name}
                                                    style={{
                                                        position: 'absolute',
                                                        inset: 0,
                                                        width: '100%',
                                                        height: '100%',
                                                        objectFit: 'cover',
                                                        objectPosition: 'top'
                                                    }}
                                                />
                                            )}
                                            <div style={{
                                                position: 'absolute',
                                                top: '1rem',
                                                right: '1rem',
                                                zIndex: 10,
                                                fontSize: '3rem',
                                                fontWeight: 900,
                                                color: 'rgba(255,255,255,0.8)',
                                                lineHeight: 1,
                                                textShadow: '2px 2px 10px rgba(0,0,0,0.5)',
                                                fontFamily: "'Archivo Black', sans-serif"
                                            }}>
                                                {String(index + 1).padStart(2, '0')}
                                            </div>
                                            <div style={{
                                                position: 'absolute',
                                                bottom: 0,
                                                left: 0,
                                                right: 0,
                                                height: '40%',
                                                background: 'linear-gradient(to top, rgba(0,0,0,0.95), rgba(0,0,0,0.7), transparent)'
                                            }}></div>
                                            <div style={{
                                                position: 'absolute',
                                                bottom: 0,
                                                left: 0,
                                                right: 0,
                                                padding: '1rem',
                                                zIndex: 10
                                            }}>
                                                {photographer.category && (
                                                    <span className="badge badge-primary" style={{ marginBottom: '0.5rem' }}>
                                                        {photographer.category}
                                                    </span>
                                                )}
                                                <h3 style={{
                                                    fontSize: '1.25rem',
                                                    fontWeight: 900,
                                                    textTransform: 'uppercase',
                                                    color: 'white',
                                                    textShadow: '0 2px 4px rgba(0,0,0,0.5)',
                                                    lineHeight: 1.2,
                                                    letterSpacing: '-0.02em'
                                                }}>
                                                    {photographer.name}
                                                </h3>
                                                {photographer.team && (
                                                    <p style={{
                                                        fontSize: '0.75rem',
                                                        color: 'rgba(255,255,255,0.7)',
                                                        marginTop: '0.25rem',
                                                        fontWeight: 500
                                                    }}>
                                                        {photographer.team}
                                                    </p>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </section>
            )}

            {/* WORKFLOW SECTION */}
            <section id="workflow" style={{ padding: '6rem 0', background: '#0a0a0a' }}>
                <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 1rem' }}>
                    <div style={{ textAlign: 'center', marginBottom: '4rem' }}>
                        <h2 style={{
                            fontSize: 'clamp(1.5rem, 4vw, 2.25rem)',
                            fontWeight: 900,
                            fontStyle: 'italic',
                            fontFamily: "'Archivo Black', sans-serif"
                        }}>
                            CARA <span style={{ color: '#39FF14' }}>KERJA</span>
                        </h2>
                        <p style={{
                            color: 'rgba(255,255,255,0.5)',
                            marginTop: '0.5rem',
                            textTransform: 'uppercase',
                            letterSpacing: '0.1em',
                            fontSize: '0.75rem'
                        }}>
                            PROSES CEPAT TANPA RIBET
                        </p>
                    </div>
                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
                        gap: '2rem'
                    }}>
                        {[
                            { num: '01', title: 'Pilih Event', desc: 'Temukan balapan yang kamu ikuti dari daftar event kami.' },
                            { num: '02', title: 'Cari Nomor', desc: 'Masukkan nama event untuk filter instan.' },
                            { num: '03', title: 'Bayar Instant', desc: 'Pilih foto terbaikmu dan bayar via QRIS/E-Wallet.' },
                            { num: '04', title: 'Terima Foto', desc: 'Link download resolusi tinggi dikirim langsung via Email.' },
                        ].map(step => (
                            <div key={step.num} style={{ textAlign: 'center' }}>
                                <div style={{
                                    width: '5rem',
                                    height: '5rem',
                                    margin: '0 auto 1.5rem',
                                    borderRadius: '50%',
                                    background: 'linear-gradient(135deg, rgba(57,255,20,0.2), transparent)',
                                    border: '2px solid rgba(57,255,20,0.3)',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    transition: 'all 0.3s'
                                }}>
                                    <span style={{
                                        fontSize: '1.5rem',
                                        fontWeight: 900,
                                        color: '#39FF14'
                                    }}>{step.num}</span>
                                </div>
                                <h4 style={{
                                    fontSize: '1.125rem',
                                    fontWeight: 700,
                                    marginBottom: '0.5rem'
                                }}>{step.title}</h4>
                                <p style={{
                                    fontSize: '0.875rem',
                                    color: 'rgba(255,255,255,0.5)',
                                    lineHeight: 1.6
                                }}>{step.desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* DIRECT BOOKING SECTION */}
            <section id="booking" style={{
                padding: '6rem 0',
                background: 'linear-gradient(135deg, #050505 0%, #0a0a0a 50%, #050505 100%)',
                position: 'relative',
                overflow: 'hidden'
            }}>
                {/* Background Decoration */}
                <div style={{
                    position: 'absolute',
                    inset: 0,
                    background: 'radial-gradient(ellipse at center, rgba(0,240,255,0.05) 0%, transparent 60%)',
                    pointerEvents: 'none'
                }}></div>

                <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 1rem', position: 'relative', zIndex: 10 }}>
                    {/* Hero Headline */}
                    <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
                        <h2 style={{
                            fontSize: 'clamp(2rem, 6vw, 3.5rem)',
                            fontWeight: 900,
                            fontStyle: 'italic',
                            lineHeight: 1.1,
                            marginBottom: '1rem',
                            fontFamily: "'Archivo Black', sans-serif"
                        }}>
                            <span style={{ color: '#00F0FF' }}>ABADIKAN</span> MOMEN<br />
                            TERCEPAT<span style={{ color: '#39FF14' }}> KAMU</span>
                        </h2>
                        <p style={{
                            color: 'rgba(255,255,255,0.6)',
                            fontSize: '1.125rem',
                            maxWidth: '600px',
                            margin: '0 auto 2.5rem',
                            lineHeight: 1.7
                        }}>
                            Hubungi kami langsung untuk booking foto balap profesional.
                            Proses cepat, hasil berkualitas tinggi.
                        </p>

                        {/* Dual CTA Buttons */}
                        <div style={{
                            display: 'flex',
                            flexWrap: 'wrap',
                            justifyContent: 'center',
                            gap: '1rem',
                            marginBottom: '4rem'
                        }}>
                            <a
                                href="https://wa.me/+6287780085484?text=Halo%2C%20saya%20ingin%20pesan%20foto%20untuk%20event"
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '0.75rem',
                                    background: 'linear-gradient(135deg, #25D366, #128C7E)',
                                    color: 'white',
                                    padding: '1rem 2.5rem',
                                    borderRadius: '9999px',
                                    fontWeight: 700,
                                    fontSize: '1rem',
                                    textDecoration: 'none',
                                    boxShadow: '0 10px 40px rgba(37,211,102,0.3)',
                                    transition: 'all 0.3s',
                                    border: 'none'
                                }}
                            >
                                <span style={{ fontSize: '1.5rem' }}>📱</span>
                                WhatsApp Kami
                            </a>
                            <a
                                href="https://instagram.com/geezplay"
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '0.75rem',
                                    background: 'rgba(255,255,255,0.05)',
                                    border: '2px solid rgba(255,255,255,0.2)',
                                    color: 'white',
                                    padding: '1rem 2.5rem',
                                    borderRadius: '9999px',
                                    fontWeight: 700,
                                    fontSize: '1rem',
                                    textDecoration: 'none',
                                    transition: 'all 0.3s'
                                }}
                            >
                                <span style={{ fontSize: '1.5rem' }}>📸</span>
                                Instagram Kami
                            </a>
                        </div>
                    </div>

                    {/* Value Proposition Grid */}
                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
                        gap: '1.5rem',
                        marginTop: '2rem'
                    }}>
                        {[
                            {
                                icon: '🎯',
                                title: 'Kualitas Terbaik',
                                desc: ' hasil profesional dengan kualitas terbaik untuk hasil tajam dan detail maksimal.',
                                color: '#00F0FF'
                            },
                            {
                                icon: '⚡',
                                title: 'Pengiriman Cepat',
                                desc: '  foto final dikirim dalam 2x24 jam.',
                                color: '#39FF14'
                            },
                            {
                                icon: '✨',
                                title: 'Booking Mudah',
                                desc: 'Tidak perlu registrasi. Langsung chat via WhatsApp, deal, dan foto!',
                                color: '#7000FF'
                            }
                        ].map((item, idx) => (
                            <div key={idx} style={{
                                background: 'rgba(255,255,255,0.02)',
                                backdropFilter: 'blur(10px)',
                                border: '1px solid rgba(255,255,255,0.08)',
                                borderRadius: '16px',
                                padding: '2rem',
                                textAlign: 'center',
                                transition: 'all 0.3s'
                            }}>
                                <div style={{
                                    width: '4rem',
                                    height: '4rem',
                                    margin: '0 auto 1.5rem',
                                    borderRadius: '50%',
                                    background: `linear-gradient(135deg, ${item.color}20, transparent)`,
                                    border: `2px solid ${item.color}40`,
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    fontSize: '1.75rem'
                                }}>
                                    {item.icon}
                                </div>
                                <h4 style={{
                                    fontSize: '1.25rem',
                                    fontWeight: 700,
                                    marginBottom: '0.75rem',
                                    color: item.color
                                }}>
                                    {item.title}
                                </h4>
                                <p style={{
                                    fontSize: '0.9rem',
                                    color: 'rgba(255,255,255,0.5)',
                                    lineHeight: 1.6
                                }}>
                                    {item.desc}
                                </p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* SPONSORS SECTION */}
            {sponsors && Object.keys(sponsors).length > 0 && (
                <section id="sponsors" style={{ padding: '5rem 0', background: '#111111' }}>
                    <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 1rem' }}>
                        <h2 style={{
                            fontSize: 'clamp(1.5rem, 4vw, 2.25rem)',
                            fontWeight: 900,
                            fontStyle: 'italic',
                            textAlign: 'center',
                            marginBottom: '3rem',
                            fontFamily: "'Archivo Black', sans-serif"
                        }}>
                            OUR <span style={{ color: '#39FF14' }}>SPONSORS</span>
                        </h2>
                        {Object.entries(sponsors).map(([categoryKey, categorySponsors]) => {
                            if (!categorySponsors || categorySponsors.length === 0) return null;
                            const categoryLabel = CATEGORY_LABELS[categoryKey] || categoryKey.charAt(0).toUpperCase() + categoryKey.slice(1);

                            return (
                                <div key={categoryKey} style={{ marginBottom: '3rem' }}>
                                    <h3 style={{
                                        fontSize: '1rem',
                                        fontWeight: 700,
                                        color: 'rgba(255,255,255,0.5)',
                                        textAlign: 'center',
                                        marginBottom: '2rem',
                                        textTransform: 'uppercase',
                                        letterSpacing: '0.1em'
                                    }}>
                                        {categoryLabel}
                                    </h3>
                                    <div style={{
                                        display: 'flex',
                                        flexWrap: 'wrap',
                                        justifyContent: 'center',
                                        alignItems: 'center',
                                        gap: '2rem'
                                    }}>
                                        {categorySponsors.map(sponsor => (
                                            <div key={sponsor._id || sponsor.id} style={{
                                                background: 'rgba(255,255,255,0.05)',
                                                borderRadius: '1rem',
                                                padding: '1.5rem 2rem',
                                                transition: 'all 0.2s',
                                                minWidth: '150px',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center'
                                            }}>
                                                {(sponsor.logo_url || sponsor.logoUrl) ? (
                                                    <img
                                                        src={sponsor.logo_url || sponsor.logoUrl}
                                                        alt={sponsor.name}
                                                        style={{
                                                            maxHeight: '80px',
                                                            maxWidth: '200px',
                                                            width: 'auto',
                                                            height: 'auto',
                                                            objectFit: 'contain'
                                                        }}
                                                        onError={(e) => {
                                                            e.target.style.display = 'none';
                                                            e.target.parentElement.querySelector('span').style.display = 'block';
                                                        }}
                                                    />
                                                ) : null}
                                                <span style={{
                                                    display: (sponsor.logo_url || sponsor.logoUrl) ? 'none' : 'block',
                                                    color: 'rgba(255,255,255,0.7)',
                                                    fontWeight: 700,
                                                    fontSize: '1rem'
                                                }}>
                                                    {sponsor.name}
                                                </span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </section>
            )}

            {/* FOOTER */}
            <footer style={{
                background: '#020202',
                borderTop: '1px solid rgba(255,255,255,0.1)',
                padding: '3rem 0'
            }}>
                <div style={{
                    maxWidth: '1280px',
                    margin: '0 auto',
                    padding: '0 1rem',
                    display: 'flex',
                    flexWrap: 'wrap',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    gap: '1.5rem'
                }}>
                    <div style={{
                        fontSize: '1.5rem',
                        fontWeight: 900,
                        fontFamily: "'Archivo Black', sans-serif"
                    }}>
                        Geez<span style={{ color: '#39FF14' }}>Play</span>
                    </div>
                    <div style={{
                        fontSize: '0.875rem',
                        color: 'rgba(255,255,255,0.5)',
                        textAlign: 'center'
                    }}>
                        © 2024 RACEPHOTO by GeezPlay. ALL RIGHTS RESERVED.
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem' }}>
                        <a href="https://www.instagram.com/geezplay/" style={{
                            color: 'rgba(255,255,255,0.5)',
                            transition: 'color 0.2s',
                            textDecoration: 'none'
                        }}>
                            📷 Instagram
                        </a>
                        <a href="#" style={{
                            color: 'rgba(255,255,255,0.5)',
                            transition: 'color 0.2s',
                            textDecoration: 'none'
                        }}>
                            🐦 Twitter
                        </a>
                        <a href="https://wa.me/+6287780085484" style={{
                            color: 'rgba(255,255,255,0.5)',
                            transition: 'color 0.2s',
                            textDecoration: 'none'
                        }}>
                            📱 WhatsApp
                        </a>
                    </div>
                </div>
            </footer>

            {/* Image Lightbox Modal */}
            {selectedEvent && (
                <div style={{
                    position: 'fixed',
                    inset: 0,
                    zIndex: 9999,
                    background: 'rgba(0,0,0,0.95)',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    padding: '1rem'
                }} onClick={handleCloseLightbox}>
                    {/* Top Bar */}
                    <div style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        right: 0,
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        padding: '1rem 1.5rem',
                        background: 'linear-gradient(to bottom, rgba(0,0,0,0.8), transparent)'
                    }} onClick={e => e.stopPropagation()}>
                        <div>
                            <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '0.25rem' }}>
                                {selectedEvent.title || selectedEvent.name}
                            </h3>
                            <p style={{ fontSize: '0.85rem', color: 'rgba(255,255,255,0.6)' }}>
                                📍 {selectedEvent.location || 'TBA'} • 🗓 {new Date(selectedEvent.start_time || selectedEvent.startTime).toLocaleDateString('id-ID')}
                            </p>
                        </div>
                        <button onClick={handleCloseLightbox} style={{
                            background: 'rgba(255,255,255,0.1)',
                            border: 'none',
                            color: 'white',
                            fontSize: '1.5rem',
                            width: '48px',
                            height: '48px',
                            borderRadius: '50%',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}>
                            ✕
                        </button>
                    </div>

                    {/* Image Container */}
                    <div style={{
                        maxWidth: '90vw',
                        maxHeight: '75vh',
                        overflow: 'auto',
                        borderRadius: '12px'
                    }} onClick={e => e.stopPropagation()}>
                        <img
                            src={selectedEvent.fullImageUrl}
                            alt={selectedEvent.title || selectedEvent.name}
                            style={{
                                transform: `scale(${zoomLevel})`,
                                transformOrigin: 'center',
                                transition: 'transform 0.3s ease',
                                maxWidth: '100%',
                                borderRadius: '12px',
                                boxShadow: '0 25px 50px rgba(0,0,0,0.5)'
                            }}
                        />
                    </div>

                    {/* Bottom Controls */}
                    <div style={{
                        position: 'absolute',
                        bottom: '2rem',
                        display: 'flex',
                        gap: '0.75rem',
                        background: 'rgba(0,0,0,0.8)',
                        padding: '0.75rem 1.5rem',
                        borderRadius: '9999px',
                        backdropFilter: 'blur(10px)',
                        border: '1px solid rgba(255,255,255,0.1)'
                    }} onClick={e => e.stopPropagation()}>
                        <button onClick={handleZoomOut} style={{
                            background: 'rgba(255,255,255,0.1)',
                            border: 'none',
                            color: 'white',
                            fontSize: '1.25rem',
                            width: '40px',
                            height: '40px',
                            borderRadius: '50%',
                            cursor: 'pointer'
                        }} title="Zoom Out">
                            ➖
                        </button>
                        <button onClick={handleResetZoom} style={{
                            background: 'rgba(0,240,255,0.2)',
                            border: '1px solid rgba(0,240,255,0.4)',
                            color: '#00F0FF',
                            fontSize: '0.8rem',
                            padding: '0 1rem',
                            borderRadius: '9999px',
                            cursor: 'pointer',
                            fontWeight: 700
                        }}>
                            {Math.round(zoomLevel * 100)}%
                        </button>
                        <button onClick={handleZoomIn} style={{
                            background: 'rgba(255,255,255,0.1)',
                            border: 'none',
                            color: 'white',
                            fontSize: '1.25rem',
                            width: '40px',
                            height: '40px',
                            borderRadius: '50%',
                            cursor: 'pointer'
                        }} title="Zoom In">
                            ➕
                        </button>
                        <div style={{ width: '1px', background: 'rgba(255,255,255,0.2)', margin: '0 0.5rem' }}></div>
                        <button onClick={handleDownload} style={{
                            background: 'linear-gradient(135deg, #39FF14, #32CD32)',
                            border: 'none',
                            color: 'black',
                            fontSize: '0.85rem',
                            padding: '0.5rem 1.5rem',
                            borderRadius: '9999px',
                            cursor: 'pointer',
                            fontWeight: 700,
                            display: 'flex',
                            alignItems: 'center',
                            gap: '0.5rem'
                        }}>
                            ⬇️ Download
                        </button>
                    </div>
                </div>
            )}

            {/* Floating WhatsApp FAB */}
            <a
                href="https://wa.me/+6287780085484?text=Halo%2C%20saya%20ingin%20booking%20foto%20untuk%20event"
                target="_blank"
                rel="noopener noreferrer"
                style={{
                    position: 'fixed',
                    bottom: '2rem',
                    right: '2rem',
                    zIndex: 1000,
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.75rem',
                    background: 'linear-gradient(135deg, #25D366, #128C7E)',
                    color: 'white',
                    padding: '1rem 1.5rem',
                    borderRadius: '9999px',
                    fontWeight: 700,
                    fontSize: '0.9rem',
                    textDecoration: 'none',
                    boxShadow: '0 10px 40px rgba(37,211,102,0.4)',
                    transition: 'all 0.3s',
                    animation: 'pulse 2s infinite'
                }}
            >
                <span style={{ fontSize: '1.25rem' }}>📱</span>
                Book via WhatsApp
            </a>
        </div>
    );
}
