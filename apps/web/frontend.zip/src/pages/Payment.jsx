import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { createOrder, createPaymentToken, updateOrderStatus } from '../services/api';

export default function Payment() {
    const navigate = useNavigate();
    const { items, getTotal, getCount, clearCart } = useCart();
    const [checkoutData, setCheckoutData] = useState({ email: '', whatsapp: '' });
    const [step, setStep] = useState(1); // 1: Form, 2: Processing
    const [isProcessing, setIsProcessing] = useState(false);
    const [paymentStatus, setPaymentStatus] = useState(null); // 'success', 'pending', 'error'
    const paymentCompleted = useRef(false); // Flag to prevent redirect after payment

    useEffect(() => {
        // Only redirect to home if cart is empty AND payment hasn't completed
        if (items.length === 0 && !paymentCompleted.current && !isProcessing) {
            navigate('/');
        }
    }, [items, navigate, isProcessing]);

    const totalPrice = getTotal();
    const isGmailValid = checkoutData.email.toLowerCase().trim().endsWith('@gmail.com');
    const isWhatsAppValid = checkoutData.whatsapp.length >= 10;
    const isFormComplete = isGmailValid && isWhatsAppValid;

    const proceedToPayment = async () => {
        if (!isFormComplete) return;

        setIsProcessing(true);
        try {
            // Map cart items - use photoId field from cart context
            const mappedItems = items.map(item => ({
                photoId: item.photoId,  // Use photoId, not id
                price: item.price,
                variant: item.variant || 1,
            }));

            // Create order - send as 'items' not 'cart'
            const orderResponse = await createOrder({
                email: checkoutData.email,
                whatsapp: checkoutData.whatsapp,
                items: mappedItems  // Backend expects 'items' array
            });

            const orderId = orderResponse.data.order_id || orderResponse.data.orderId || orderResponse.data.id;

            // Get Snap token
            const tokenResponse = await createPaymentToken(orderId);
            const snapToken = tokenResponse.data.snap_token || tokenResponse.data.snapToken || tokenResponse.data.token;

            if (!snapToken) {
                throw new Error('Failed to get payment token');
            }

            setStep(2);

            // Open Midtrans Snap
            window.snap.pay(snapToken, {
                onSuccess: function (result) {
                    console.log('Payment success:', result);
                    paymentCompleted.current = true;
                    setPaymentStatus('success');
                    clearCart();

                    // Navigate immediately - don't wait for API
                    navigate(`/success?order_id=${orderId}&status=success`);

                    // Update order status in background (fire and forget)
                    updateOrderStatus(orderId, 'success').catch(err => {
                        console.error('Failed to update order status:', err);
                    });
                },
                onPending: function (result) {
                    console.log('Payment pending:', result);
                    paymentCompleted.current = true; // Set flag before clearing cart
                    setPaymentStatus('pending');
                    clearCart();
                    // Navigate immediately to success page
                    navigate(`/success?order_id=${orderId}&status=pending`);
                },
                onError: function (result) {
                    console.error('Payment error:', result);
                    setPaymentStatus('error');
                    setIsProcessing(false);
                },
                onClose: function () {
                    console.log('Payment popup closed');
                    if (!paymentCompleted.current) {
                        setStep(1);
                        setIsProcessing(false);
                    }
                }
            });

        } catch (error) {
            console.error('Payment process failed:', error);
            const msg = error.response?.data?.message || error.response?.data?.error || 'Gagal memproses pembayaran. Silakan coba lagi.';
            alert(msg);
            setIsProcessing(false);
        }
    };

    return (
        <div className="app-wrapper">
            {/* Navbar */}
            <nav className="main-navbar">
                <div className="navbar-inner">
                    <Link to="/" className="logo-link">
                        <div className="logo-icon">📷</div>
                        <span className="logo-text">GEEZ<span className="accent">PLAY</span></span>
                    </Link>
                </div>
            </nav>

            <div style={{
                paddingTop: '6rem',
                paddingBottom: '6rem',
                maxWidth: '600px',
                margin: '0 auto',
                padding: '6rem 1rem'
            }}>
                {/* Header */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
                    <button
                        onClick={() => step === 2 && !isProcessing ? setStep(1) : navigate('/cart')}
                        disabled={isProcessing}
                        style={{
                            background: 'rgba(255,255,255,0.05)',
                            padding: '0.625rem',
                            borderRadius: '12px',
                            border: '1px solid rgba(255,255,255,0.1)',
                            color: 'white',
                            cursor: isProcessing ? 'not-allowed' : 'pointer',
                            opacity: isProcessing ? 0.5 : 1
                        }}
                    >
                        ◀
                    </button>
                    <h2 style={{
                        fontSize: '1.5rem',
                        fontWeight: '900',
                        textTransform: 'uppercase',
                        fontStyle: 'italic',
                        letterSpacing: '-0.02em'
                    }}>
                        {step === 1 ? 'Data Penerima' : 'Pembayaran'}
                    </h2>
                </div>

                {step === 1 ? (
                    <div style={{
                        background: '#0a0a0a',
                        border: '1px solid rgba(255,255,255,0.1)',
                        padding: '2rem',
                        borderRadius: '32px',
                        boxShadow: '0 25px 50px -12px rgba(0,0,0,0.5)'
                    }}>
                        {/* Summary */}
                        <div style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            borderBottom: '1px solid rgba(255,255,255,0.1)',
                            paddingBottom: '1.5rem',
                            marginBottom: '1.5rem'
                        }}>
                            <div>
                                <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '10px', textTransform: 'uppercase', fontWeight: '700', letterSpacing: '0.1em' }}>
                                    Total Tagihan
                                </p>
                                <p style={{ fontSize: '1.5rem', fontWeight: '900', color: '#39FF14', fontStyle: 'italic' }}>
                                    Rp {totalPrice.toLocaleString()}
                                </p>
                            </div>
                            <div style={{ textAlign: 'right' }}>
                                <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '10px', textTransform: 'uppercase', fontWeight: '700', letterSpacing: '0.1em' }}>
                                    Jumlah Item
                                </p>
                                <p style={{ fontSize: '1.25rem', fontWeight: '900', color: 'white', fontStyle: 'italic' }}>
                                    {getCount()} Foto
                                </p>
                            </div>
                        </div>

                        {/* Form */}
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                            {/* Email */}
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                                <label style={{
                                    fontSize: '10px',
                                    textTransform: 'uppercase',
                                    fontWeight: '900',
                                    color: '#39FF14',
                                    letterSpacing: '0.1em',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '0.5rem'
                                }}>
                                    📧 Email (Wajib @gmail.com)
                                </label>
                                <input
                                    type="email"
                                    value={checkoutData.email}
                                    onChange={(e) => setCheckoutData({ ...checkoutData, email: e.target.value })}
                                    placeholder="contoh@gmail.com"
                                    style={{
                                        width: '100%',
                                        background: 'rgba(0,0,0,0.5)',
                                        border: checkoutData.email && !isGmailValid ? '1px solid rgba(239,68,68,0.5)' : '1px solid rgba(255,255,255,0.1)',
                                        borderRadius: '12px',
                                        padding: '1rem 1.5rem',
                                        color: 'white',
                                        fontSize: '1rem',
                                        boxSizing: 'border-box'
                                    }}
                                />
                                <p style={{ fontSize: '10px', color: 'rgba(255,255,255,0.3)' }}>
                                    File foto akan dikirim ke email ini.
                                </p>
                            </div>

                            {/* WhatsApp */}
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                                <label style={{
                                    fontSize: '10px',
                                    textTransform: 'uppercase',
                                    fontWeight: '900',
                                    color: '#39FF14',
                                    letterSpacing: '0.1em',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '0.5rem'
                                }}>
                                    📱 WhatsApp (Aktif)
                                </label>
                                <input
                                    type="tel"
                                    inputMode="numeric"
                                    value={checkoutData.whatsapp}
                                    onChange={(e) => {
                                        const val = e.target.value.replace(/[^0-9]/g, '');
                                        setCheckoutData({ ...checkoutData, whatsapp: val });
                                    }}
                                    placeholder="0812..."
                                    style={{
                                        width: '100%',
                                        background: 'rgba(0,0,0,0.5)',
                                        border: '1px solid rgba(255,255,255,0.1)',
                                        borderRadius: '12px',
                                        padding: '1rem 1.5rem',
                                        color: 'white',
                                        fontSize: '1rem',
                                        boxSizing: 'border-box'
                                    }}
                                />
                            </div>
                        </div>

                        {/* Submit Button */}
                        <button
                            onClick={proceedToPayment}
                            disabled={!isFormComplete || isProcessing}
                            style={{
                                width: '100%',
                                padding: '1rem',
                                borderRadius: '12px',
                                fontWeight: '900',
                                textTransform: 'uppercase',
                                fontStyle: 'italic',
                                letterSpacing: '0.05em',
                                marginTop: '1.5rem',
                                border: 'none',
                                cursor: isFormComplete && !isProcessing ? 'pointer' : 'not-allowed',
                                background: isFormComplete && !isProcessing ? '#39FF14' : 'rgba(255,255,255,0.05)',
                                color: isFormComplete && !isProcessing ? 'black' : 'rgba(255,255,255,0.2)',
                                boxShadow: isFormComplete && !isProcessing ? '0 0 20px rgba(57,255,20,0.3)' : 'none',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '0.5rem'
                            }}
                        >
                            {isProcessing ? (
                                <>⏳ Memproses...</>
                            ) : (
                                <>💳 Bayar Sekarang →</>
                            )}
                        </button>

                        {/* Payment Methods */}
                        <div style={{
                            marginTop: '1.5rem',
                            paddingTop: '1.5rem',
                            borderTop: '1px solid rgba(255,255,255,0.1)'
                        }}>
                            <p style={{
                                fontSize: '10px',
                                textTransform: 'uppercase',
                                fontWeight: '700',
                                color: 'rgba(255,255,255,0.3)',
                                letterSpacing: '0.1em',
                                marginBottom: '0.75rem'
                            }}>
                                Metode Pembayaran
                            </p>
                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', justifyContent: 'center' }}>
                                {['QRIS', 'GoPay', 'OVO', 'DANA', 'Kartu Kredit', 'BCA VA', 'Mandiri VA'].map((method) => (
                                    <span
                                        key={method}
                                        style={{
                                            fontSize: '10px',
                                            background: 'rgba(255,255,255,0.05)',
                                            border: '1px solid rgba(255,255,255,0.1)',
                                            padding: '0.375rem 0.75rem',
                                            borderRadius: '9999px',
                                            color: 'rgba(255,255,255,0.5)'
                                        }}
                                    >
                                        {method}
                                    </span>
                                ))}
                            </div>
                        </div>
                    </div>
                ) : (
                    <div>
                        <div style={{
                            background: '#0a0a0a',
                            border: '1px solid rgba(255,255,255,0.1)',
                            padding: '2rem',
                            borderRadius: '32px',
                            boxShadow: '0 25px 50px -12px rgba(0,0,0,0.5)'
                        }}>
                            {paymentStatus === 'success' ? (
                                <div style={{ textAlign: 'center', padding: '2rem 0' }}>
                                    <div style={{
                                        width: '80px',
                                        height: '80px',
                                        background: 'rgba(57,255,20,0.1)',
                                        borderRadius: '50%',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        margin: '0 auto 1rem',
                                        fontSize: '2.5rem'
                                    }}>
                                        ✓
                                    </div>
                                    <h3 style={{ fontSize: '1.25rem', fontWeight: '900', color: '#39FF14', marginBottom: '0.5rem' }}>
                                        Pembayaran Berhasil!
                                    </h3>
                                    <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.875rem' }}>
                                        Mengalihkan ke halaman sukses...
                                    </p>
                                </div>
                            ) : paymentStatus === 'pending' ? (
                                <div style={{ textAlign: 'center', padding: '2rem 0' }}>
                                    <div style={{
                                        width: '80px',
                                        height: '80px',
                                        background: 'rgba(245,158,11,0.1)',
                                        borderRadius: '50%',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        margin: '0 auto 1rem',
                                        fontSize: '2.5rem'
                                    }}>
                                        ⏳
                                    </div>
                                    <h3 style={{ fontSize: '1.25rem', fontWeight: '900', color: '#f59e0b', marginBottom: '0.5rem' }}>
                                        Menunggu Pembayaran
                                    </h3>
                                    <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.875rem' }}>
                                        Silakan selesaikan pembayaran Anda...
                                    </p>
                                </div>
                            ) : paymentStatus === 'error' ? (
                                <div style={{ textAlign: 'center', padding: '2rem 0' }}>
                                    <div style={{
                                        width: '80px',
                                        height: '80px',
                                        background: 'rgba(239,68,68,0.1)',
                                        borderRadius: '50%',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        margin: '0 auto 1rem',
                                        fontSize: '2.5rem',
                                        color: '#ef4444'
                                    }}>
                                        ✕
                                    </div>
                                    <h3 style={{ fontSize: '1.25rem', fontWeight: '900', color: '#ef4444', marginBottom: '0.5rem' }}>
                                        Pembayaran Gagal
                                    </h3>
                                    <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.875rem', marginBottom: '1rem' }}>
                                        Terjadi kesalahan saat memproses pembayaran.
                                    </p>
                                    <button
                                        onClick={() => {
                                            setStep(1);
                                            setPaymentStatus(null);
                                        }}
                                        style={{
                                            background: 'rgba(255,255,255,0.1)',
                                            color: 'white',
                                            fontWeight: '700',
                                            padding: '0.5rem 1.5rem',
                                            borderRadius: '12px',
                                            border: 'none',
                                            cursor: 'pointer'
                                        }}
                                    >
                                        Coba Lagi
                                    </button>
                                </div>
                            ) : (
                                <div style={{ textAlign: 'center', padding: '2rem 0' }}>
                                    <div style={{
                                        width: '80px',
                                        height: '80px',
                                        background: 'rgba(57,255,20,0.1)',
                                        borderRadius: '50%',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        margin: '0 auto 1rem',
                                        fontSize: '2.5rem'
                                    }}>
                                        ⏳
                                    </div>
                                    <h3 style={{ fontSize: '1.25rem', fontWeight: '900', color: 'white', marginBottom: '0.5rem' }}>
                                        Memproses Pembayaran
                                    </h3>
                                    <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.875rem' }}>
                                        Popup pembayaran Midtrans akan muncul...
                                    </p>
                                </div>
                            )}
                        </div>

                        {/* Total */}
                        <div style={{
                            marginTop: '1.5rem',
                            background: '#0a0a0a',
                            padding: '1.5rem',
                            borderRadius: '24px',
                            border: '1px solid rgba(255,255,255,0.1)'
                        }}>
                            <p style={{
                                fontSize: '10px',
                                textTransform: 'uppercase',
                                fontWeight: '900',
                                color: 'rgba(255,255,255,0.3)',
                                letterSpacing: '0.1em',
                                marginBottom: '0.25rem'
                            }}>
                                Total Transfer
                            </p>
                            <p style={{
                                fontSize: '1.875rem',
                                fontWeight: '900',
                                color: '#39FF14',
                                fontStyle: 'italic',
                                letterSpacing: '-0.02em'
                            }}>
                                Rp {totalPrice.toLocaleString()}
                            </p>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
