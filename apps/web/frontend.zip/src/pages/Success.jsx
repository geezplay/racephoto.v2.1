import { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { getOrder } from '../services/api';

export default function Success() {
    const [searchParams] = useSearchParams();
    const orderId = searchParams.get('order_id');
    const urlStatus = searchParams.get('status'); // Get status from URL
    const [order, setOrder] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchOrder = async () => {
            if (!orderId) {
                setLoading(false);
                return;
            }

            try {
                const res = await getOrder(orderId);
                setOrder(res.data);
            } catch (error) {
                console.error('Error fetching order:', error);
            } finally {
                setLoading(false);
            }
        };
        fetchOrder();
    }, [orderId]);

    const formatPrice = (price) => {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
        }).format(price);
    };

    if (loading) {
        return (
            <div className="loading-screen">
                <div className="spinner"></div>
            </div>
        );
    }

    // Prioritize URL status over database status
    // If URL says success, show success (because Midtrans callback confirmed it)
    const isSuccess = urlStatus === 'success' || order?.status === 'success';
    const isPending = !isSuccess && (urlStatus === 'pending' || order?.status === 'pending');

    return (
        <div className="app-wrapper">
            {/* Navbar */}
            <nav className="main-navbar">
                <div className="navbar-inner">
                    <Link to="/" className="logo-link">
                        <div className="logo-icon">📷</div>
                        <span className="logo-text">GEEZ<span className="accent">PLAY</span></span>
                    </Link>
                </div>
            </nav>

            {/* Success Content */}
            <div style={{
                paddingTop: '6rem',
                paddingBottom: '4rem',
                maxWidth: '600px',
                margin: '0 auto',
                padding: '6rem 1rem 4rem',
                textAlign: 'center'
            }}>
                <div style={{
                    background: '#0a0a0a',
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '32px',
                    padding: '3rem 2rem',
                    boxShadow: '0 25px 50px -12px rgba(0,0,0,0.5)'
                }}>
                    {isPending ? (
                        <>
                            <div style={{
                                width: '80px',
                                height: '80px',
                                background: 'rgba(245,158,11,0.1)',
                                borderRadius: '50%',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                margin: '0 auto 1.5rem',
                                fontSize: '2.5rem'
                            }}>
                                ⏳
                            </div>
                            <h1 style={{
                                fontSize: '1.5rem',
                                fontWeight: '900',
                                textTransform: 'uppercase',
                                fontStyle: 'italic',
                                marginBottom: '0.5rem',
                                color: '#f59e0b'
                            }}>
                                Menunggu Pembayaran
                            </h1>
                            <p style={{ color: 'rgba(255,255,255,0.5)', marginBottom: '2rem' }}>
                                Silakan selesaikan pembayaran Anda. Foto akan dikirim ke email setelah pembayaran dikonfirmasi.
                            </p>
                        </>
                    ) : (
                        <>
                            <div style={{
                                width: '80px',
                                height: '80px',
                                background: 'rgba(57,255,20,0.1)',
                                borderRadius: '50%',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                margin: '0 auto 1.5rem',
                                fontSize: '2.5rem',
                                color: '#39FF14'
                            }}>
                                ✓
                            </div>
                            <h1 style={{
                                fontSize: '1.5rem',
                                fontWeight: '900',
                                textTransform: 'uppercase',
                                fontStyle: 'italic',
                                marginBottom: '0.5rem',
                                color: '#39FF14'
                            }}>
                                Pembayaran Berhasil!
                            </h1>
                            <p style={{ color: 'rgba(255,255,255,0.5)', marginBottom: '2rem' }}>
                                Terima kasih atas pembelian Anda. Foto sudah dikirim ke email Anda.
                            </p>
                        </>
                    )}

                    {order && (
                        <div style={{
                            background: 'rgba(0,0,0,0.3)',
                            padding: '1.5rem',
                            borderRadius: '20px',
                            textAlign: 'left',
                            marginBottom: '2rem'
                        }}>
                            <h4 style={{
                                fontSize: '0.75rem',
                                textTransform: 'uppercase',
                                fontWeight: '900',
                                color: '#39FF14',
                                letterSpacing: '0.1em',
                                marginBottom: '1rem'
                            }}>
                                Detail Pesanan
                            </h4>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', fontSize: '0.875rem' }}>
                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <span style={{ color: 'rgba(255,255,255,0.4)' }}>Order ID</span>
                                    <span style={{ fontFamily: 'monospace' }}>{order._id || order.id}</span>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <span style={{ color: 'rgba(255,255,255,0.4)' }}>Email</span>
                                    <span>{order.email}</span>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <span style={{ color: 'rgba(255,255,255,0.4)' }}>Jumlah Item</span>
                                    <span>{order.items?.length || 0} foto</span>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <span style={{ color: 'rgba(255,255,255,0.4)' }}>Total</span>
                                    <span style={{ color: '#39FF14', fontWeight: '900' }}>
                                        {formatPrice(order.totalPrice || order.total_price)}
                                    </span>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                    <span style={{ color: 'rgba(255,255,255,0.4)' }}>Status</span>
                                    <span style={{
                                        background: isSuccess ? 'rgba(57,255,20,0.1)' : 'rgba(245,158,11,0.1)',
                                        color: isSuccess ? '#39FF14' : '#f59e0b',
                                        padding: '0.25rem 0.75rem',
                                        borderRadius: '9999px',
                                        fontSize: '0.75rem',
                                        fontWeight: '700',
                                        textTransform: 'uppercase'
                                    }}>
                                        {isSuccess ? 'SUCCESS' : 'PENDING'}
                                    </span>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Purchased Photos Section */}
                    {isSuccess && order?.items && order.items.length > 0 && (
                        <div style={{
                            background: 'rgba(0,0,0,0.3)',
                            padding: '1.5rem',
                            borderRadius: '20px',
                            textAlign: 'left',
                            marginBottom: '2rem'
                        }}>
                            <h4 style={{
                                fontSize: '0.75rem',
                                textTransform: 'uppercase',
                                fontWeight: '900',
                                color: '#39FF14',
                                letterSpacing: '0.1em',
                                marginBottom: '1rem'
                            }}>
                                📷 Foto yang Dibeli
                            </h4>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                                {order.items.map((item, idx) => {
                                    const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

                                    // Helper to construct full URL
                                    const getFullUrl = (path) => {
                                        if (!path) return null;
                                        if (path.startsWith('http')) return path;
                                        return `${API_URL}${path}`;
                                    };

                                    // Priority: recapUrl > mainPhotoUrl > photoUrl
                                    const photoUrl = getFullUrl(item.recapUrl) || getFullUrl(item.mainPhotoUrl) || getFullUrl(item.photoUrl);

                                    return (
                                        <div key={item.id || idx} style={{
                                            display: 'flex',
                                            gap: '1rem',
                                            alignItems: 'center',
                                            padding: '1rem',
                                            background: 'rgba(255,255,255,0.03)',
                                            borderRadius: '12px',
                                            border: '1px solid rgba(255,255,255,0.1)'
                                        }}>
                                            {/* Photo Thumbnail */}
                                            <div style={{
                                                width: '80px',
                                                height: '80px',
                                                borderRadius: '8px',
                                                overflow: 'hidden',
                                                flexShrink: 0,
                                                background: 'rgba(0,0,0,0.5)'
                                            }}>
                                                {photoUrl ? (
                                                    <img
                                                        src={photoUrl}
                                                        alt={`Foto ${idx + 1}`}
                                                        style={{
                                                            width: '100%',
                                                            height: '100%',
                                                            objectFit: 'cover'
                                                        }}
                                                        onError={(e) => {
                                                            // Prevent infinite loop - only replace if not already a fallback
                                                            if (!e.target.dataset.fallback) {
                                                                e.target.dataset.fallback = 'true';
                                                                e.target.style.display = 'none';
                                                                e.target.parentNode.innerHTML = '<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,0.3);font-size:1.5rem">📷</div>';
                                                            }
                                                        }}
                                                    />
                                                ) : (
                                                    <div style={{
                                                        width: '100%',
                                                        height: '100%',
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        justifyContent: 'center',
                                                        color: 'rgba(255,255,255,0.3)',
                                                        fontSize: '1.5rem'
                                                    }}>📷</div>
                                                )}
                                            </div>

                                            {/* Photo Details */}
                                            <div style={{ flex: 1 }}>
                                                <div style={{
                                                    fontSize: '0.875rem',
                                                    fontWeight: '700',
                                                    marginBottom: '0.25rem'
                                                }}>
                                                    {item.eventName || 'Event'}
                                                </div>
                                                <div style={{
                                                    fontSize: '0.75rem',
                                                    color: 'rgba(255,255,255,0.5)'
                                                }}>
                                                    Start #{item.startNo} • Varian {item.variant}
                                                </div>
                                                <div style={{
                                                    fontSize: '0.75rem',
                                                    color: '#39FF14',
                                                    fontWeight: '700',
                                                    marginTop: '0.25rem'
                                                }}>
                                                    {formatPrice(item.price)}
                                                </div>
                                            </div>

                                            {/* Download Button */}
                                            <a
                                                href={`${API_URL}/api/photos/download-by-order/${orderId}/${idx}`}
                                                style={{
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    gap: '0.5rem',
                                                    padding: '0.5rem 1rem',
                                                    background: '#39FF14',
                                                    color: 'black',
                                                    borderRadius: '8px',
                                                    fontWeight: '700',
                                                    fontSize: '0.75rem',
                                                    textDecoration: 'none',
                                                    textTransform: 'uppercase'
                                                }}
                                            >
                                                ⬇ Download
                                            </a>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    )}

                    <Link
                        to="/"
                        style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '0.5rem',
                            background: '#39FF14',
                            color: 'black',
                            padding: '1rem 2rem',
                            borderRadius: '12px',
                            fontWeight: '900',
                            textTransform: 'uppercase',
                            fontStyle: 'italic',
                            letterSpacing: '-0.02em',
                            textDecoration: 'none',
                            boxShadow: '0 15px 30px rgba(57,255,20,0.3)'
                        }}
                    >
                        ← Kembali ke Home
                    </Link>
                </div>
            </div>
        </div>
    );
}
