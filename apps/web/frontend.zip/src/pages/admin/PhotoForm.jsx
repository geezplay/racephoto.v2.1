import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import AdminLayout from '../../components/AdminLayout';
import { getAdminPhoto, uploadPhoto, updatePhoto, getAdminEvents, getAdminEvent, uploadRecaps, deleteRecap } from '../../services/api';

export default function PhotoForm() {
    const { id } = useParams();
    const navigate = useNavigate();
    const isEdit = Boolean(id);
    const [loading, setLoading] = useState(false);
    const [saving, setSaving] = useState(false);
    const [events, setEvents] = useState([]);
    const [classes, setClasses] = useState([]);
    const [formData, setFormData] = useState({
        event_id: '',
        class_name: '',
        start_no: '',
        price: '',
        image: null
    });
    const [preview, setPreview] = useState(null);

    // Recap photos state
    const [recaps, setRecaps] = useState([]);
    const [recapFiles, setRecapFiles] = useState([]);
    const [uploadingRecaps, setUploadingRecaps] = useState(false);

    useEffect(() => {
        fetchEvents();
        if (isEdit) {
            fetchPhoto();
        }
    }, [id]);

    // Load classes when event changes
    useEffect(() => {
        if (formData.event_id) {
            fetchEventClasses(formData.event_id);
        } else {
            setClasses([]);
        }
    }, [formData.event_id]);

    const fetchEvents = async () => {
        try {
            const res = await getAdminEvents();
            setEvents(res.data);
        } catch (error) {
            console.error('Error fetching events:', error);
        }
    };

    const fetchEventClasses = async (eventId) => {
        try {
            const res = await getAdminEvent(eventId);
            if (res.data.classes) {
                setClasses(res.data.classes);
            } else {
                setClasses([]);
            }
        } catch (error) {
            console.error('Error fetching event classes:', error);
            setClasses([]);
        }
    };

    const fetchPhoto = async () => {
        setLoading(true);
        try {
            const res = await getAdminPhoto(id);
            const photo = res.data;
            setFormData({
                event_id: photo.event_id || '',
                class_name: photo.class || '',
                start_no: photo.start_no || photo.startNo || '',
                price: photo.price || '',
                image: null
            });
            if (photo.photoUrl || photo.url) {
                setPreview(photo.photoUrl || photo.url);
            }
            // Load existing recaps
            if (photo.recaps) {
                setRecaps(photo.recaps);
            }
        } catch (error) {
            console.error('Error fetching photo:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setFormData(prev => ({ ...prev, image: file }));
            setPreview(URL.createObjectURL(file));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSaving(true);
        try {
            const data = new FormData();
            data.append('eventId', formData.event_id);
            data.append('class', formData.class_name);
            data.append('startNo', formData.start_no);
            data.append('price', formData.price);
            if (formData.image) {
                data.append('photo', formData.image);
            }

            if (isEdit) {
                await updatePhoto(id, data);
            } else {
                await uploadPhoto(data);
            }
            navigate('/admin');
        } catch (error) {
            console.error('Error saving photo:', error);
            alert('Gagal menyimpan foto');
        } finally {
            setSaving(false);
        }
    };

    // Recap handlers
    const handleRecapFilesChange = (e) => {
        const files = Array.from(e.target.files);
        setRecapFiles(files);
    };

    const handleUploadRecaps = async () => {
        if (recapFiles.length === 0 || !id) return;
        setUploadingRecaps(true);
        try {
            const formData = new FormData();
            recapFiles.forEach(file => {
                formData.append('recaps', file);
            });

            const res = await uploadRecaps(id, formData);
            // Refresh recaps
            await fetchPhoto();
            setRecapFiles([]);
            // Clear file input
            const fileInput = document.getElementById('recap-files');
            if (fileInput) fileInput.value = '';
        } catch (error) {
            console.error('Error uploading recaps:', error);
            alert('Gagal mengupload varian foto');
        } finally {
            setUploadingRecaps(false);
        }
    };

    const handleDeleteRecap = async (recapId) => {
        if (!confirm('Hapus varian foto ini?')) return;
        try {
            await deleteRecap(recapId);
            setRecaps(recaps.filter(r => r.id !== recapId));
        } catch (error) {
            console.error('Error deleting recap:', error);
            alert('Gagal menghapus varian foto');
        }
    };

    if (loading) {
        return (
            <AdminLayout title={isEdit ? 'Edit Foto' : 'Upload Foto'}>
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '50vh' }}>
                    <div className="spinner"></div>
                </div>
            </AdminLayout>
        );
    }

    return (
        <AdminLayout title={isEdit ? 'Edit Foto' : 'Upload Foto Baru'} subtitle="Kelola katalog foto">
            <div style={{ maxWidth: '1000px' }}>
                <Link
                    to="/admin"
                    style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.5rem',
                        color: 'rgba(255,255,255,0.4)',
                        textDecoration: 'none',
                        marginBottom: '1.5rem',
                        fontSize: '0.875rem'
                    }}
                >
                    ← Kembali ke Dashboard
                </Link>

                <div style={{ display: 'grid', gridTemplateColumns: isEdit ? '1fr 1fr' : '1fr', gap: '2rem' }}>
                    {/* Photo Form */}
                    <form onSubmit={handleSubmit} style={{
                        background: '#0a0a0a',
                        padding: '2rem',
                        borderRadius: '24px',
                        border: '1px solid rgba(255,255,255,0.05)'
                    }}>
                        <h3 style={{
                            fontSize: '1rem',
                            fontWeight: '900',
                            textTransform: 'uppercase',
                            marginBottom: '1.5rem',
                            color: '#39FF14'
                        }}>
                            📸 Detail Foto
                        </h3>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                            {/* Event */}
                            <div>
                                <label style={{
                                    display: 'block',
                                    fontSize: '10px',
                                    textTransform: 'uppercase',
                                    fontWeight: '900',
                                    color: 'rgba(255,255,255,0.4)',
                                    letterSpacing: '0.1em',
                                    marginBottom: '0.5rem'
                                }}>
                                    📅 Event
                                </label>
                                <select
                                    name="event_id"
                                    value={formData.event_id}
                                    onChange={handleChange}
                                    required
                                    style={{
                                        width: '100%',
                                        background: 'rgba(0,0,0,0.5)',
                                        border: '1px solid rgba(255,255,255,0.1)',
                                        borderRadius: '12px',
                                        padding: '1rem',
                                        color: 'white',
                                        fontSize: '1rem',
                                        boxSizing: 'border-box'
                                    }}
                                >
                                    <option value="">Pilih Event...</option>
                                    {events.map(event => (
                                        <option key={event.id || event._id} value={event.id || event._id}>{event.name}</option>
                                    ))}
                                </select>
                            </div>

                            {/* Class Name */}
                            <div>
                                <label style={{
                                    display: 'block',
                                    fontSize: '10px',
                                    textTransform: 'uppercase',
                                    fontWeight: '900',
                                    color: 'rgba(255,255,255,0.4)',
                                    letterSpacing: '0.1em',
                                    marginBottom: '0.5rem'
                                }}>
                                    🏁 Kelas Balap
                                </label>
                                {classes.length > 0 ? (
                                    <select
                                        name="class_name"
                                        value={formData.class_name}
                                        onChange={handleChange}
                                        required
                                        style={{
                                            width: '100%',
                                            background: 'rgba(0,0,0,0.5)',
                                            border: '1px solid rgba(255,255,255,0.1)',
                                            borderRadius: '12px',
                                            padding: '1rem',
                                            color: 'white',
                                            fontSize: '1rem',
                                            boxSizing: 'border-box'
                                        }}
                                    >
                                        <option value="">Pilih Kelas...</option>
                                        {classes.map(cls => (
                                            <option key={cls.id || cls._id} value={cls.name}>{cls.name}</option>
                                        ))}
                                    </select>
                                ) : (
                                    <input
                                        type="text"
                                        name="class_name"
                                        value={formData.class_name}
                                        onChange={handleChange}
                                        required
                                        style={{
                                            width: '100%',
                                            background: 'rgba(0,0,0,0.5)',
                                            border: '1px solid rgba(255,255,255,0.1)',
                                            borderRadius: '12px',
                                            padding: '1rem',
                                            color: 'white',
                                            fontSize: '1rem',
                                            boxSizing: 'border-box'
                                        }}
                                        placeholder="Contoh: MotoGP, Superbike"
                                    />
                                )}
                            </div>

                            {/* Start No */}
                            <div>
                                <label style={{
                                    display: 'block',
                                    fontSize: '10px',
                                    textTransform: 'uppercase',
                                    fontWeight: '900',
                                    color: 'rgba(255,255,255,0.4)',
                                    letterSpacing: '0.1em',
                                    marginBottom: '0.5rem'
                                }}>
                                    🔢 Nomor Start
                                </label>
                                <input
                                    type="text"
                                    name="start_no"
                                    value={formData.start_no}
                                    onChange={handleChange}
                                    required
                                    style={{
                                        width: '100%',
                                        background: 'rgba(0,0,0,0.5)',
                                        border: '1px solid rgba(255,255,255,0.1)',
                                        borderRadius: '12px',
                                        padding: '1rem',
                                        color: 'white',
                                        fontSize: '1rem',
                                        boxSizing: 'border-box'
                                    }}
                                    placeholder="46, 93, etc."
                                />
                            </div>

                            {/* Price */}
                            <div>
                                <label style={{
                                    display: 'block',
                                    fontSize: '10px',
                                    textTransform: 'uppercase',
                                    fontWeight: '900',
                                    color: 'rgba(255,255,255,0.4)',
                                    letterSpacing: '0.1em',
                                    marginBottom: '0.5rem'
                                }}>
                                    💰 Harga (Rp)
                                </label>
                                <input
                                    type="number"
                                    name="price"
                                    value={formData.price}
                                    onChange={handleChange}
                                    required
                                    style={{
                                        width: '100%',
                                        background: 'rgba(0,0,0,0.5)',
                                        border: '1px solid rgba(255,255,255,0.1)',
                                        borderRadius: '12px',
                                        padding: '1rem',
                                        color: 'white',
                                        fontSize: '1rem',
                                        boxSizing: 'border-box'
                                    }}
                                    placeholder="50000"
                                />
                            </div>

                            {/* Image */}
                            <div>
                                <label style={{
                                    display: 'block',
                                    fontSize: '10px',
                                    textTransform: 'uppercase',
                                    fontWeight: '900',
                                    color: 'rgba(255,255,255,0.4)',
                                    letterSpacing: '0.1em',
                                    marginBottom: '0.5rem'
                                }}>
                                    🖼️ Foto Utama
                                </label>
                                <input
                                    type="file"
                                    accept="image/*"
                                    onChange={handleImageChange}
                                    required={!isEdit}
                                    style={{
                                        width: '100%',
                                        background: 'rgba(0,0,0,0.5)',
                                        border: '1px solid rgba(255,255,255,0.1)',
                                        borderRadius: '12px',
                                        padding: '1rem',
                                        color: 'white',
                                        fontSize: '0.875rem',
                                        boxSizing: 'border-box'
                                    }}
                                />
                                {preview && (
                                    <img
                                        src={preview}
                                        alt="Preview"
                                        style={{
                                            marginTop: '1rem',
                                            width: '100%',
                                            maxHeight: '200px',
                                            objectFit: 'cover',
                                            borderRadius: '12px'
                                        }}
                                    />
                                )}
                            </div>

                            {/* Submit */}
                            <button
                                type="submit"
                                disabled={saving}
                                style={{
                                    width: '100%',
                                    background: '#39FF14',
                                    color: 'black',
                                    padding: '1rem',
                                    borderRadius: '12px',
                                    fontWeight: '900',
                                    textTransform: 'uppercase',
                                    fontStyle: 'italic',
                                    border: 'none',
                                    cursor: saving ? 'not-allowed' : 'pointer',
                                    opacity: saving ? 0.5 : 1,
                                    boxShadow: '0 15px 30px rgba(57,255,20,0.3)'
                                }}
                            >
                                {saving ? '⏳ Menyimpan...' : isEdit ? '💾 Update Foto' : '📤 Upload Foto'}
                            </button>
                        </div>
                    </form>

                    {/* Recap Photos Section - Only show when editing */}
                    {isEdit && (
                        <div style={{
                            background: '#0a0a0a',
                            padding: '2rem',
                            borderRadius: '24px',
                            border: '1px solid rgba(255,255,255,0.05)'
                        }}>
                            <h3 style={{
                                fontSize: '1rem',
                                fontWeight: '900',
                                textTransform: 'uppercase',
                                marginBottom: '1.5rem',
                                color: '#39FF14'
                            }}>
                                📷 Varian Foto / Recap
                            </h3>

                            {/* Upload Recaps */}
                            <div style={{ marginBottom: '1.5rem' }}>
                                <label style={{
                                    display: 'block',
                                    fontSize: '10px',
                                    textTransform: 'uppercase',
                                    fontWeight: '900',
                                    color: 'rgba(255,255,255,0.4)',
                                    letterSpacing: '0.1em',
                                    marginBottom: '0.5rem'
                                }}>
                                    Upload Varian Baru (Multiple)
                                </label>
                                <div style={{ display: 'flex', gap: '0.5rem' }}>
                                    <input
                                        id="recap-files"
                                        type="file"
                                        accept="image/*"
                                        multiple
                                        onChange={handleRecapFilesChange}
                                        style={{
                                            flex: 1,
                                            background: 'rgba(0,0,0,0.5)',
                                            border: '1px solid rgba(255,255,255,0.1)',
                                            borderRadius: '8px',
                                            padding: '0.75rem',
                                            color: 'white',
                                            fontSize: '0.75rem'
                                        }}
                                    />
                                    <button
                                        type="button"
                                        onClick={handleUploadRecaps}
                                        disabled={uploadingRecaps || recapFiles.length === 0}
                                        style={{
                                            background: '#39FF14',
                                            color: 'black',
                                            padding: '0.75rem 1rem',
                                            borderRadius: '8px',
                                            border: 'none',
                                            fontWeight: '700',
                                            cursor: uploadingRecaps || recapFiles.length === 0 ? 'not-allowed' : 'pointer',
                                            opacity: uploadingRecaps || recapFiles.length === 0 ? 0.5 : 1,
                                            whiteSpace: 'nowrap'
                                        }}
                                    >
                                        {uploadingRecaps ? '...' : `📤 Upload (${recapFiles.length})`}
                                    </button>
                                </div>
                            </div>

                            {/* Existing Recaps */}
                            <div>
                                <label style={{
                                    display: 'block',
                                    fontSize: '10px',
                                    textTransform: 'uppercase',
                                    fontWeight: '900',
                                    color: 'rgba(255,255,255,0.4)',
                                    letterSpacing: '0.1em',
                                    marginBottom: '0.75rem'
                                }}>
                                    Varian Tersimpan ({recaps.length})
                                </label>

                                {recaps.length === 0 ? (
                                    <div style={{
                                        padding: '2rem',
                                        textAlign: 'center',
                                        color: 'rgba(255,255,255,0.3)',
                                        background: 'rgba(0,0,0,0.3)',
                                        borderRadius: '12px'
                                    }}>
                                        <div style={{ fontSize: '2rem', marginBottom: '0.5rem', opacity: 0.5 }}>📷</div>
                                        <p style={{ fontSize: '0.875rem' }}>Belum ada varian foto</p>
                                        <p style={{ fontSize: '0.75rem', marginTop: '0.25rem' }}>Upload varian untuk ditampilkan di recap</p>
                                    </div>
                                ) : (
                                    <div style={{
                                        display: 'grid',
                                        gridTemplateColumns: 'repeat(auto-fill, minmax(80px, 1fr))',
                                        gap: '0.5rem',
                                        maxHeight: '300px',
                                        overflowY: 'auto',
                                        padding: '0.5rem',
                                        background: 'rgba(0,0,0,0.3)',
                                        borderRadius: '12px'
                                    }}>
                                        {recaps.map((recap, index) => (
                                            <div
                                                key={recap.id}
                                                style={{
                                                    position: 'relative',
                                                    aspectRatio: '1',
                                                    borderRadius: '8px',
                                                    overflow: 'hidden',
                                                    border: '1px solid rgba(255,255,255,0.1)'
                                                }}
                                            >
                                                <img
                                                    src={recap.url}
                                                    alt={`Varian ${index + 1}`}
                                                    style={{
                                                        width: '100%',
                                                        height: '100%',
                                                        objectFit: 'cover'
                                                    }}
                                                    onError={(e) => { e.target.src = '/placeholder.jpg'; }}
                                                />
                                                <div style={{
                                                    position: 'absolute',
                                                    bottom: 0,
                                                    left: 0,
                                                    right: 0,
                                                    background: 'linear-gradient(transparent, rgba(0,0,0,0.8))',
                                                    padding: '0.5rem 0.25rem 0.25rem',
                                                    display: 'flex',
                                                    justifyContent: 'space-between',
                                                    alignItems: 'center'
                                                }}>
                                                    <span style={{ fontSize: '0.625rem', color: 'white', fontWeight: '700' }}>
                                                        #{recap.variant_number || index + 1}
                                                    </span>
                                                    <button
                                                        onClick={() => handleDeleteRecap(recap.id)}
                                                        style={{
                                                            background: 'rgba(239,68,68,0.8)',
                                                            border: 'none',
                                                            padding: '0.125rem 0.25rem',
                                                            borderRadius: '2px',
                                                            color: 'white',
                                                            cursor: 'pointer',
                                                            fontSize: '0.5rem'
                                                        }}
                                                    >
                                                        ✕
                                                    </button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>

                            <p style={{
                                marginTop: '1rem',
                                fontSize: '0.75rem',
                                color: 'rgba(255,255,255,0.3)',
                                fontStyle: 'italic'
                            }}>
                                💡 Varian foto akan ditampilkan saat pembeli melihat detail foto ini
                            </p>
                        </div>
                    )}
                </div>
            </div>
        </AdminLayout>
    );
}
