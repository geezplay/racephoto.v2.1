import { useState, useEffect } from 'react';
import AdminLayout from '../../components/AdminLayout';
import { getPhotographers, createPhotographer, updatePhotographer, deletePhotographer } from '../../services/api';

export default function PhotographerManagement() {
    const [photographers, setPhotographers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showForm, setShowForm] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [formData, setFormData] = useState({
        name: '',
        category: '',
        team: '',
        gradient_from: '#39FF14',
        gradient_to: '#00D4FF',
        photo: null
    });

    useEffect(() => {
        fetchPhotographers();
    }, []);

    const fetchPhotographers = async () => {
        try {
            const res = await getPhotographers();
            setPhotographers(res.data);
        } catch (error) {
            console.error('Error fetching photographers:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const data = new FormData();
            data.append('name', formData.name);
            data.append('category', formData.category);
            data.append('team', formData.team);
            data.append('gradient_from', formData.gradient_from);
            data.append('gradient_to', formData.gradient_to);
            if (formData.photo) {
                data.append('photo', formData.photo);
            }

            if (editingId) {
                await updatePhotographer(editingId, data);
            } else {
                await createPhotographer(data);
            }
            fetchPhotographers();
            resetForm();
        } catch (error) {
            console.error('Error saving photographer:', error);
        }
    };

    const handleEdit = (photographer) => {
        setEditingId(photographer.id);
        setFormData({
            name: photographer.name,
            category: photographer.category || '',
            team: photographer.team || '',
            gradient_from: photographer.gradient_from || '#39FF14',
            gradient_to: photographer.gradient_to || '#00D4FF',
            photo: null
        });
        setShowForm(true);
    };

    const handleDelete = async (id) => {
        if (!confirm('Hapus fotografer ini?')) return;
        try {
            await deletePhotographer(id);
            fetchPhotographers();
        } catch (error) {
            console.error('Error deleting photographer:', error);
        }
    };

    const resetForm = () => {
        setShowForm(false);
        setEditingId(null);
        setFormData({ name: '', category: '', team: '', gradient_from: '#39FF14', gradient_to: '#00D4FF', photo: null });
    };

    if (loading) {
        return (
            <AdminLayout title="Fotografer">
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '50vh' }}>
                    <div className="spinner"></div>
                </div>
            </AdminLayout>
        );
    }

    return (
        <AdminLayout title="Kelola Fotografer" subtitle="Tambah dan kelola fotografer">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
                <h3 style={{ fontSize: '1.25rem', fontWeight: '900', textTransform: 'uppercase', fontStyle: 'italic' }}>
                    Daftar Fotografer
                </h3>
                <button
                    onClick={() => setShowForm(!showForm)}
                    style={{
                        background: '#39FF14',
                        color: 'black',
                        padding: '0.5rem 1rem',
                        borderRadius: '8px',
                        fontSize: '0.75rem',
                        fontWeight: '900',
                        border: 'none',
                        cursor: 'pointer'
                    }}
                >
                    ➕ TAMBAH FOTOGRAFER
                </button>
            </div>

            {/* Form */}
            {showForm && (
                <form onSubmit={handleSubmit} style={{
                    background: '#0a0a0a',
                    padding: '1.5rem',
                    borderRadius: '16px',
                    border: '1px solid rgba(255,255,255,0.05)',
                    marginBottom: '1.5rem'
                }}>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
                        <div>
                            <label style={{ display: 'block', fontSize: '10px', textTransform: 'uppercase', fontWeight: '900', color: '#39FF14', marginBottom: '0.5rem' }}>
                                Nama
                            </label>
                            <input
                                type="text"
                                value={formData.name}
                                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                required
                                style={{
                                    width: '100%',
                                    background: 'rgba(0,0,0,0.5)',
                                    border: '1px solid rgba(255,255,255,0.1)',
                                    borderRadius: '8px',
                                    padding: '0.75rem',
                                    color: 'white',
                                    boxSizing: 'border-box'
                                }}
                            />
                        </div>
                        <div>
                            <label style={{ display: 'block', fontSize: '10px', textTransform: 'uppercase', fontWeight: '900', color: '#39FF14', marginBottom: '0.5rem' }}>
                                Kategori
                            </label>
                            <input
                                type="text"
                                value={formData.category}
                                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                                placeholder="MotoGP, Superbike, etc."
                                style={{
                                    width: '100%',
                                    background: 'rgba(0,0,0,0.5)',
                                    border: '1px solid rgba(255,255,255,0.1)',
                                    borderRadius: '8px',
                                    padding: '0.75rem',
                                    color: 'white',
                                    boxSizing: 'border-box'
                                }}
                            />
                        </div>
                        <div>
                            <label style={{ display: 'block', fontSize: '10px', textTransform: 'uppercase', fontWeight: '900', color: '#39FF14', marginBottom: '0.5rem' }}>
                                Team
                            </label>
                            <input
                                type="text"
                                value={formData.team}
                                onChange={(e) => setFormData({ ...formData, team: e.target.value })}
                                style={{
                                    width: '100%',
                                    background: 'rgba(0,0,0,0.5)',
                                    border: '1px solid rgba(255,255,255,0.1)',
                                    borderRadius: '8px',
                                    padding: '0.75rem',
                                    color: 'white',
                                    boxSizing: 'border-box'
                                }}
                            />
                        </div>
                        <div>
                            <label style={{ display: 'block', fontSize: '10px', textTransform: 'uppercase', fontWeight: '900', color: '#39FF14', marginBottom: '0.5rem' }}>
                                Gradient From
                            </label>
                            <input
                                type="color"
                                value={formData.gradient_from}
                                onChange={(e) => setFormData({ ...formData, gradient_from: e.target.value })}
                                style={{
                                    width: '100%',
                                    height: '40px',
                                    background: 'rgba(0,0,0,0.5)',
                                    border: '1px solid rgba(255,255,255,0.1)',
                                    borderRadius: '8px',
                                    cursor: 'pointer'
                                }}
                            />
                        </div>
                        <div>
                            <label style={{ display: 'block', fontSize: '10px', textTransform: 'uppercase', fontWeight: '900', color: '#39FF14', marginBottom: '0.5rem' }}>
                                Gradient To
                            </label>
                            <input
                                type="color"
                                value={formData.gradient_to}
                                onChange={(e) => setFormData({ ...formData, gradient_to: e.target.value })}
                                style={{
                                    width: '100%',
                                    height: '40px',
                                    background: 'rgba(0,0,0,0.5)',
                                    border: '1px solid rgba(255,255,255,0.1)',
                                    borderRadius: '8px',
                                    cursor: 'pointer'
                                }}
                            />
                        </div>
                        <div>
                            <label style={{ display: 'block', fontSize: '10px', textTransform: 'uppercase', fontWeight: '900', color: '#39FF14', marginBottom: '0.5rem' }}>
                                Foto
                            </label>
                            <input
                                type="file"
                                accept="image/*"
                                onChange={(e) => setFormData({ ...formData, photo: e.target.files[0] })}
                                style={{
                                    width: '100%',
                                    background: 'rgba(0,0,0,0.5)',
                                    border: '1px solid rgba(255,255,255,0.1)',
                                    borderRadius: '8px',
                                    padding: '0.5rem',
                                    color: 'white',
                                    boxSizing: 'border-box'
                                }}
                            />
                        </div>
                    </div>
                    <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1rem' }}>
                        <button type="submit" style={{
                            background: '#39FF14',
                            color: 'black',
                            padding: '0.5rem 1rem',
                            borderRadius: '8px',
                            fontWeight: '700',
                            border: 'none',
                            cursor: 'pointer'
                        }}>
                            {editingId ? '💾 Update' : '➕ Tambah'}
                        </button>
                        <button type="button" onClick={resetForm} style={{
                            background: 'rgba(255,255,255,0.1)',
                            color: 'white',
                            padding: '0.5rem 1rem',
                            borderRadius: '8px',
                            fontWeight: '700',
                            border: 'none',
                            cursor: 'pointer'
                        }}>
                            Batal
                        </button>
                    </div>
                </form>
            )}

            {/* Photographer Grid */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '1rem' }}>
                {photographers.map(photographer => (
                    <div key={photographer.id} style={{
                        background: `linear-gradient(135deg, ${photographer.gradient_from || '#39FF14'}20, ${photographer.gradient_to || '#00D4FF'}20)`,
                        padding: '1.5rem',
                        borderRadius: '16px',
                        border: '1px solid rgba(255,255,255,0.05)',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        gap: '1rem'
                    }}>
                        {photographer.photoUrl || photographer.photo ? (
                            <img
                                src={photographer.photoUrl || photographer.photo}
                                alt={photographer.name}
                                style={{ width: '80px', height: '80px', objectFit: 'cover', borderRadius: '50%' }}
                            />
                        ) : (
                            <div style={{
                                width: '80px',
                                height: '80px',
                                background: `linear-gradient(135deg, ${photographer.gradient_from || '#39FF14'}, ${photographer.gradient_to || '#00D4FF'})`,
                                borderRadius: '50%',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                fontSize: '2rem'
                            }}>
                                📷
                            </div>
                        )}
                        <div style={{ textAlign: 'center' }}>
                            <p style={{ fontWeight: '900', marginBottom: '0.25rem' }}>{photographer.name}</p>
                            {photographer.category && (
                                <span style={{
                                    fontSize: '0.75rem',
                                    color: 'rgba(255,255,255,0.5)'
                                }}>
                                    {photographer.category}
                                </span>
                            )}
                        </div>
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                            <button onClick={() => handleEdit(photographer)} style={{
                                padding: '0.5rem',
                                background: 'rgba(255,255,255,0.1)',
                                borderRadius: '8px',
                                border: 'none',
                                color: 'white',
                                cursor: 'pointer'
                            }}>✏️</button>
                            <button onClick={() => handleDelete(photographer.id)} style={{
                                padding: '0.5rem',
                                background: 'rgba(255,255,255,0.1)',
                                borderRadius: '8px',
                                border: 'none',
                                color: 'white',
                                cursor: 'pointer'
                            }}>🗑️</button>
                        </div>
                    </div>
                ))}
                {photographers.length === 0 && (
                    <div style={{
                        gridColumn: '1 / -1',
                        background: '#0a0a0a',
                        padding: '3rem',
                        borderRadius: '16px',
                        border: '1px solid rgba(255,255,255,0.05)',
                        textAlign: 'center'
                    }}>
                        <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem', opacity: 0.2 }}>📷</div>
                        <p style={{ color: 'rgba(255,255,255,0.3)' }}>Belum ada fotografer</p>
                    </div>
                )}
            </div>
        </AdminLayout>
    );
}
