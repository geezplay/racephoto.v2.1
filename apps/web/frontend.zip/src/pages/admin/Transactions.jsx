import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import AdminLayout from '../../components/AdminLayout';
import { getAdminTransactions } from '../../services/api';
import {
    Camera,
    User,
    ShoppingCart,
    CheckCircle,
    Clock,
    XCircle,
    X
} from 'lucide-react';

export default function Transactions() {
    const [transactions, setTransactions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [expandedId, setExpandedId] = useState(null);
    const [filters, setFilters] = useState({ events: [], classes: [] });

    // Filter states
    const [sortOrder, setSortOrder] = useState('desc'); // desc = terbaru, asc = terlama
    const [filterEvent, setFilterEvent] = useState('');
    const [filterClass, setFilterClass] = useState('');
    const [filterStatus, setFilterStatus] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');

    useEffect(() => {
        fetchTransactions();
    }, []);

    const fetchTransactions = async () => {
        try {
            const res = await getAdminTransactions();
            // Handle new format with orders and filters
            if (res.data.orders) {
                setTransactions(res.data.orders);
                setFilters(res.data.filters || { events: [], classes: [] });
            } else {
                // Fallback for old format (array response)
                const data = Array.isArray(res.data) ? res.data : [];
                setTransactions(data);
            }
        } catch (error) {
            console.error('Error fetching transactions:', error);
        } finally {
            setLoading(false);
        }
    };

    const formatPrice = (price) => {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
        }).format(price || 0);
    };

    const formatDate = (date) => {
        if (!date) return '-';
        try {
            return new Date(date).toLocaleDateString('id-ID', {
                day: 'numeric',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        } catch (e) {
            return '-';
        }
    };

    const getStatusStyle = (status) => {
        const styles = {
            success: { bg: 'rgba(57,255,20,0.1)', color: '#39FF14' },
            pending: { bg: 'rgba(245,158,11,0.1)', color: '#f59e0b' },
            failed: { bg: 'rgba(239,68,68,0.1)', color: '#ef4444' },
            cancelled: { bg: 'rgba(156,163,175,0.1)', color: '#9ca3af' }
        };
        return styles[status] || styles.pending;
    };

    // Apply filters and sorting
    const filteredTransactions = transactions
        .filter(tx => {
            // Filter by status
            if (filterStatus && tx.status !== filterStatus) return false;

            // Filter by event
            if (filterEvent) {
                const hasEvent = tx.items?.some(item =>
                    (item.snap_event_name && item.snap_event_name.toLowerCase().includes(filterEvent.toLowerCase())) ||
                    (item.photo?.event_name && item.photo.event_name.toLowerCase().includes(filterEvent.toLowerCase()))
                );
                if (!hasEvent) return false;
            }

            // Filter by class
            if (filterClass) {
                const hasClass = tx.items?.some(item =>
                    (item.snap_photo_class && item.snap_photo_class.toLowerCase().includes(filterClass.toLowerCase())) ||
                    (item.photo?.class && item.photo.class.toLowerCase().includes(filterClass.toLowerCase()))
                );
                if (!hasClass) return false;
            }

            // Filter by date range
            const txDate = new Date(tx.createdAt || tx.created_at);
            if (startDate) {
                const start = new Date(startDate);
                start.setHours(0, 0, 0, 0);
                if (txDate < start) return false;
            }
            if (endDate) {
                const end = new Date(endDate);
                end.setHours(23, 59, 59, 999);
                if (txDate > end) return false;
            }

            return true;
        })
        .sort((a, b) => {
            const dateA = new Date(a.createdAt || a.created_at);
            const dateB = new Date(b.createdAt || b.created_at);
            return sortOrder === 'desc' ? dateB - dateA : dateA - dateB;
        });

    if (loading) {
        return (
            <AdminLayout title="Transaksi">
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '50vh' }}>
                    <div className="spinner"></div>
                </div>
            </AdminLayout>
        );
    }

    const selectStyle = {
        padding: '0.5rem 1rem',
        borderRadius: '8px',
        border: '1px solid rgba(255,255,255,0.1)',
        background: 'rgba(0,0,0,0.5)',
        color: 'white',
        fontSize: '0.875rem',
        minWidth: '150px',
        cursor: 'pointer'
    };

    return (
        <AdminLayout title="Transaksi" subtitle="Histori pembelian foto">
            {/* Filter Section */}
            <div style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: '1rem',
                marginBottom: '1.5rem',
                padding: '1rem',
                background: 'rgba(255,255,255,0.02)',
                borderRadius: '12px',
                border: '1px solid rgba(255,255,255,0.05)'
            }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <span style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase' }}>
                        Urutkan:
                    </span>
                    <select
                        value={sortOrder}
                        onChange={(e) => setSortOrder(e.target.value)}
                        style={selectStyle}
                    >
                        <option value="desc">Terbaru</option>
                        <option value="asc">Terlama</option>
                    </select>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <span style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase' }}>
                        Status:
                    </span>
                    <select
                        value={filterStatus}
                        onChange={(e) => setFilterStatus(e.target.value)}
                        style={selectStyle}
                    >
                        <option value="">Semua</option>
                        <option value="success">Sukses</option>
                        <option value="pending">Pending</option>
                        <option value="failed">Gagal</option>
                    </select>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <span style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase' }}>
                        Event:
                    </span>
                    <select
                        value={filterEvent}
                        onChange={(e) => setFilterEvent(e.target.value)}
                        style={selectStyle}
                    >
                        <option value="">Semua Event</option>
                        {filters.events.map(event => (
                            <option key={event} value={event}>{event}</option>
                        ))}
                    </select>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <span style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase' }}>
                        Kelas:
                    </span>
                    <select
                        value={filterClass}
                        onChange={(e) => setFilterClass(e.target.value)}
                        style={selectStyle}
                    >
                        <option value="">Semua Kelas</option>
                        {filters.classes.map(cls => (
                            <option key={cls} value={cls}>{cls}</option>
                        ))}
                    </select>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <span style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase' }}>
                        Dari:
                    </span>
                    <input
                        type="date"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                        style={{
                            ...selectStyle,
                            minWidth: '130px'
                        }}
                    />
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <span style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase' }}>
                        Sampai:
                    </span>
                    <input
                        type="date"
                        value={endDate}
                        onChange={(e) => setEndDate(e.target.value)}
                        style={{
                            ...selectStyle,
                            minWidth: '130px'
                        }}
                    />
                </div>

                {(filterStatus || filterEvent || filterClass || startDate || endDate) && (
                    <button
                        onClick={() => {
                            setFilterStatus('');
                            setFilterEvent('');
                            setFilterClass('');
                            setStartDate('');
                            setEndDate('');
                        }}
                        style={{
                            padding: '0.5rem 1rem',
                            borderRadius: '8px',
                            border: 'none',
                            background: 'rgba(239,68,68,0.2)',
                            color: '#ef4444',
                            fontSize: '0.75rem',
                            cursor: 'pointer'
                        }}
                    >
                        ✕ Reset Filter
                    </button>
                )}

                <div style={{ marginLeft: 'auto', fontSize: '0.75rem', color: 'rgba(255,255,255,0.4)' }}>
                    {filteredTransactions.length} transaksi
                </div>
            </div>

            <div style={{
                background: '#0a0a0a',
                borderRadius: '24px',
                border: '1px solid rgba(255,255,255,0.05)',
                overflow: 'hidden'
            }}>
                <table style={{ width: '100%', textAlign: 'left', fontSize: '0.875rem', borderCollapse: 'collapse' }}>
                    <thead>
                        <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.05)', background: 'rgba(255,255,255,0.05)' }}>
                            <th style={{ padding: '1rem', fontWeight: '900', textTransform: 'uppercase', color: 'rgba(255,255,255,0.4)', fontSize: '0.75rem' }}>Order ID</th>
                            <th style={{ padding: '1rem', fontWeight: '900', textTransform: 'uppercase', color: 'rgba(255,255,255,0.4)', fontSize: '0.75rem' }}>Email / WA</th>
                            <th style={{ padding: '1rem', fontWeight: '900', textTransform: 'uppercase', color: 'rgba(255,255,255,0.4)', fontSize: '0.75rem' }}>Items</th>
                            <th style={{ padding: '1rem', fontWeight: '900', textTransform: 'uppercase', color: 'rgba(255,255,255,0.4)', fontSize: '0.75rem' }}>Total</th>
                            <th style={{ padding: '1rem', fontWeight: '900', textTransform: 'uppercase', color: 'rgba(255,255,255,0.4)', fontSize: '0.75rem' }}>Status</th>
                            <th style={{ padding: '1rem', fontWeight: '900', textTransform: 'uppercase', color: 'rgba(255,255,255,0.4)', fontSize: '0.75rem' }}>Tanggal & Jam</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredTransactions.map(tx => {
                            const txId = tx.id || tx._id;
                            const isExpanded = expandedId === txId;
                            const statusStyle = getStatusStyle(tx.status);

                            return (
                                <>
                                    <tr
                                        key={txId}
                                        style={{
                                            borderBottom: isExpanded ? 'none' : '1px solid rgba(255,255,255,0.05)',
                                            cursor: 'pointer',
                                            background: isExpanded ? 'rgba(57,255,20,0.05)' : 'transparent'
                                        }}
                                        onClick={() => setExpandedId(isExpanded ? null : txId)}
                                    >
                                        <td style={{ padding: '1rem', fontFamily: 'monospace', fontSize: '0.75rem' }}>
                                            #{txId}
                                        </td>
                                        <td style={{ padding: '1rem' }}>
                                            <div>{tx.email}</div>
                                            {tx.whatsapp && <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.4)' }}>{tx.whatsapp}</div>}
                                        </td>
                                        <td style={{ padding: '1rem' }}>
                                            <span style={{
                                                background: 'rgba(57,255,20,0.1)',
                                                color: '#39FF14',
                                                padding: '0.25rem 0.5rem',
                                                borderRadius: '4px',
                                                fontSize: '0.75rem'
                                            }}>
                                                {tx.items?.length || 0} foto
                                            </span>
                                        </td>
                                        <td style={{ padding: '1rem', fontWeight: '900', color: '#39FF14' }}>
                                            {formatPrice(tx.totalPrice || tx.total_price)}
                                        </td>
                                        <td style={{ padding: '1rem' }}>
                                            <span style={{
                                                padding: '0.25rem 0.75rem',
                                                borderRadius: '9999px',
                                                fontSize: '0.75rem',
                                                fontWeight: '700',
                                                textTransform: 'uppercase',
                                                background: statusStyle.bg,
                                                color: statusStyle.color
                                            }}>
                                                {tx.status === 'success' ? 'Sukses' :
                                                    tx.status === 'pending' ? 'Pending' :
                                                        tx.status === 'failed' ? 'Gagal' : tx.status}
                                            </span>
                                        </td>
                                        <td style={{ padding: '1rem', color: 'rgba(255,255,255,0.6)', fontSize: '0.75rem' }}>
                                            {formatDate(tx.createdAt || tx.created_at)}
                                        </td>
                                    </tr>
                                    {/* Expanded Details */}
                                    {isExpanded && tx.items && tx.items.length > 0 && (
                                        <tr key={`${txId}-details`}>
                                            <td colSpan="6" style={{
                                                padding: '0 1rem 1rem 1rem',
                                                background: 'rgba(57,255,20,0.02)',
                                                borderBottom: '1px solid rgba(255,255,255,0.05)'
                                            }}>
                                                <div style={{
                                                    background: 'rgba(0,0,0,0.3)',
                                                    borderRadius: '12px',
                                                    padding: '1rem',
                                                    marginTop: '0.5rem'
                                                }}>
                                                    <h4 style={{
                                                        fontSize: '0.75rem',
                                                        fontWeight: '900',
                                                        color: '#39FF14',
                                                        textTransform: 'uppercase',
                                                        marginBottom: '1rem',
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        gap: '0.5rem'
                                                    }}>
                                                        <Camera size={16} /> Detail Item
                                                    </h4>
                                                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                                                        {tx.items.map((item, idx) => (
                                                            <div key={item.id || idx} style={{
                                                                display: 'flex',
                                                                justifyContent: 'space-between',
                                                                alignItems: 'center',
                                                                padding: '0.75rem',
                                                                background: 'rgba(255,255,255,0.03)',
                                                                borderRadius: '8px',
                                                                border: '1px solid rgba(255,255,255,0.05)'
                                                            }}>
                                                                <div style={{ flex: 1 }}>
                                                                    <div style={{ fontWeight: '700', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                                                        <Camera size={14} /> {item.snap_event_name || item.photo?.event_name || 'Event'} -
                                                                        No. {item.snap_photo_start_no || item.photo?.start_no || '-'}
                                                                    </div>
                                                                    <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)', marginTop: '0.25rem' }}>
                                                                        Kelas: {item.snap_photo_class || item.photo?.class || '-'} • Varian: {item.variant || 1}
                                                                    </div>
                                                                    {/* Admin Source Info */}
                                                                    {item.photo?.creator_name && (
                                                                        <div style={{
                                                                            fontSize: '0.7rem',
                                                                            color: 'rgba(57,255,20,0.7)',
                                                                            marginTop: '0.25rem',
                                                                            display: 'flex',
                                                                            alignItems: 'center',
                                                                            gap: '0.25rem'
                                                                        }}>
                                                                            <User size={12} /> Upload oleh: <strong>{item.photo.creator_name}</strong>
                                                                            {item.photo.creator_email && (
                                                                                <span style={{ color: 'rgba(255,255,255,0.4)' }}>
                                                                                    ({item.photo.creator_email})
                                                                                </span>
                                                                            )}
                                                                        </div>
                                                                    )}
                                                                </div>
                                                                <div style={{
                                                                    fontWeight: '900',
                                                                    color: '#39FF14',
                                                                    fontSize: '0.875rem'
                                                                }}>
                                                                    {formatPrice(item.price)}
                                                                </div>
                                                            </div>
                                                        ))}
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    )}
                                </>
                            );
                        })}
                        {filteredTransactions.length === 0 && (
                            <tr>
                                <td colSpan="6" style={{ padding: '3rem', textAlign: 'center', color: 'rgba(255,255,255,0.3)' }}>
                                    <div style={{ marginBottom: '0.5rem', opacity: 0.5 }}><ShoppingCart size={40} /></div>
                                    <p>{transactions.length === 0 ? 'Belum ada transaksi' : 'Tidak ada transaksi yang sesuai filter'}</p>
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </AdminLayout>
    );
}
