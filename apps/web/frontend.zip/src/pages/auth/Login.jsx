import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { login as loginApi } from '../../services/api';

export default function Login() {
    const navigate = useNavigate();
    const { login } = useAuth();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [formData, setFormData] = useState({
        email: '',
        password: '',
        remember: false
    });

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);

        try {
            const res = await loginApi(formData.email, formData.password);
            login(res.data.token, res.data.user);
            navigate('/admin');
        } catch (err) {
            setError(err.response?.data?.message || 'Login gagal. Periksa email dan password Anda.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{
            minHeight: '100vh',
            background: '#020202',
            color: 'white',
            fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '1rem'
        }}>
            <div style={{ width: '100%', maxWidth: '28rem' }}>
                {/* Logo */}
                <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '0.75rem',
                    marginBottom: '2.5rem'
                }}>
                    <div style={{
                        background: '#39FF14',
                        padding: '0.5rem',
                        borderRadius: '0.5rem',
                        fontSize: '1.75rem'
                    }}>
                        📷
                    </div>
                    <h1 style={{
                        fontWeight: 900,
                        fontSize: '1.5rem',
                        letterSpacing: '-0.02em',
                        textTransform: 'uppercase',
                        fontStyle: 'italic',
                        fontFamily: "'Archivo Black', sans-serif"
                    }}>
                        RacePhoto
                    </h1>
                </div>

                {/* Login Card */}
                <div style={{
                    background: '#0a0a0a',
                    borderRadius: '1.5rem',
                    padding: '2rem',
                    border: '1px solid rgba(255,255,255,0.1)',
                    boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)'
                }}>
                    <h2 style={{
                        fontSize: '1.5rem',
                        fontWeight: 900,
                        textTransform: 'uppercase',
                        fontStyle: 'italic',
                        letterSpacing: '-0.02em',
                        marginBottom: '0.5rem',
                        textAlign: 'center',
                        fontFamily: "'Archivo Black', sans-serif"
                    }}>
                        Login Admin
                    </h2>
                    <p style={{
                        color: 'rgba(255,255,255,0.4)',
                        fontSize: '0.875rem',
                        textAlign: 'center',
                        marginBottom: '2rem'
                    }}>
                        Masuk ke panel administrasi
                    </p>

                    {/* Error */}
                    {error && (
                        <div style={{
                            background: 'rgba(239, 68, 68, 0.1)',
                            border: '1px solid rgba(239, 68, 68, 0.3)',
                            borderRadius: '0.75rem',
                            padding: '1rem',
                            marginBottom: '1.5rem',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '0.75rem'
                        }}>
                            <span style={{ color: '#ef4444' }}>⚠️</span>
                            <p style={{ color: '#f87171', fontSize: '0.875rem', margin: 0 }}>{error}</p>
                        </div>
                    )}

                    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                        {/* Email */}
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                            <label style={{
                                fontSize: '10px',
                                textTransform: 'uppercase',
                                fontWeight: 900,
                                color: '#39FF14',
                                marginLeft: '0.25rem',
                                letterSpacing: '0.1em',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '0.5rem'
                            }}>
                                📧 Email
                            </label>
                            <input
                                type="email"
                                value={formData.email}
                                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                placeholder="admin@racephoto.com"
                                required
                                style={{
                                    width: '100%',
                                    background: 'rgba(0,0,0,0.5)',
                                    border: '1px solid rgba(255,255,255,0.1)',
                                    borderRadius: '0.75rem',
                                    padding: '1rem 1.5rem',
                                    color: 'white',
                                    fontSize: '1rem',
                                    transition: 'all 0.2s',
                                    outline: 'none',
                                    boxSizing: 'border-box'
                                }}
                            />
                        </div>

                        {/* Password */}
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                            <label style={{
                                fontSize: '10px',
                                textTransform: 'uppercase',
                                fontWeight: 900,
                                color: '#39FF14',
                                marginLeft: '0.25rem',
                                letterSpacing: '0.1em',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '0.5rem'
                            }}>
                                🔒 Password
                            </label>
                            <div style={{ position: 'relative' }}>
                                <input
                                    type={showPassword ? 'text' : 'password'}
                                    value={formData.password}
                                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                                    placeholder="••••••••"
                                    required
                                    style={{
                                        width: '100%',
                                        background: 'rgba(0,0,0,0.5)',
                                        border: '1px solid rgba(255,255,255,0.1)',
                                        borderRadius: '0.75rem',
                                        padding: '1rem 3rem 1rem 1.5rem',
                                        color: 'white',
                                        fontSize: '1rem',
                                        transition: 'all 0.2s',
                                        outline: 'none',
                                        boxSizing: 'border-box'
                                    }}
                                />
                                <button
                                    type="button"
                                    onClick={() => setShowPassword(!showPassword)}
                                    style={{
                                        position: 'absolute',
                                        right: '1rem',
                                        top: '50%',
                                        transform: 'translateY(-50%)',
                                        background: 'transparent',
                                        border: 'none',
                                        color: 'rgba(255,255,255,0.5)',
                                        cursor: 'pointer',
                                        fontSize: '1.25rem',
                                        padding: '0.25rem',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center'
                                    }}
                                    title={showPassword ? 'Sembunyikan password' : 'Tampilkan password'}
                                >
                                    {showPassword ? '🙈' : '👁️'}
                                </button>
                            </div>
                        </div>

                        {/* Remember */}
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                            <input
                                type="checkbox"
                                id="remember"
                                checked={formData.remember}
                                onChange={(e) => setFormData({ ...formData, remember: e.target.checked })}
                                style={{
                                    width: '1rem',
                                    height: '1rem',
                                    accentColor: '#39FF14'
                                }}
                            />
                            <label htmlFor="remember" style={{ color: 'rgba(255,255,255,0.6)', fontSize: '0.875rem' }}>
                                Ingat saya
                            </label>
                        </div>

                        {/* Submit */}
                        <button
                            type="submit"
                            disabled={loading}
                            style={{
                                width: '100%',
                                background: '#39FF14',
                                color: 'black',
                                padding: '1rem',
                                borderRadius: '1rem',
                                fontWeight: 900,
                                textTransform: 'uppercase',
                                fontSize: '1.125rem',
                                fontStyle: 'italic',
                                border: 'none',
                                cursor: loading ? 'not-allowed' : 'pointer',
                                transition: 'all 0.2s',
                                boxShadow: '0 15px 30px rgba(57, 255, 20, 0.3)',
                                opacity: loading ? 0.5 : 1,
                                fontFamily: "'Archivo Black', sans-serif"
                            }}
                        >
                            {loading ? 'Loading...' : 'Masuk'}
                        </button>
                    </form>
                </div>

                {/* Back Link */}
                <div style={{ marginTop: '2rem', textAlign: 'center' }}>
                    <Link
                        to="/"
                        style={{
                            color: 'rgba(255,255,255,0.2)',
                            fontSize: '0.75rem',
                            textDecoration: 'none',
                            transition: 'color 0.2s'
                        }}
                    >
                        ← Kembali ke halaman utama
                    </Link>
                </div>
            </div>
        </div>
    );
}
