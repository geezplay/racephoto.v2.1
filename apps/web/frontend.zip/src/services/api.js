import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || '/api';

// Create axios instance
const api = axios.create({
    baseURL: API_URL,
    headers: {
        'Content-Type': 'application/json'
    }
});

// Add token to requests
api.interceptors.request.use((config) => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

// Handle auth errors
api.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response?.status === 401) {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            window.location.href = '/login';
        }
        return Promise.reject(error);
    }
);

// Auth
export const login = (email, password) => api.post('/auth/login', { email, password });
export const logout = () => api.post('/auth/logout');
export const getMe = () => api.get('/auth/me');

// Events (Public)
export const getEvents = () => api.get('/events');
export const getEvent = (id) => api.get(`/events/${id}`);

// Photos (Public)
export const getPhotosByClass = (eventId, className, params = {}) =>
    api.get(`/photos/event/${eventId}/class/${encodeURIComponent(className)}`, { params });
export const getClassPhotos = (eventId, className) =>
    api.get(`/photos/event/${eventId}/class/${encodeURIComponent(className)}`);
export const getPhoto = (id) => api.get(`/photos/${id}`);

// Orders (Public)
export const createOrder = (data) => api.post('/orders', data);
export const getOrder = (id) => api.get(`/orders/${id}`);
export const updateOrderStatus = (id, status) => api.put(`/orders/${id}/status`, { status });

// Payment
export const createPaymentToken = (orderId) => api.post('/payment/create-token', { orderId });

// Admin - Dashboard
export const getDashboard = () => api.get('/admin/dashboard');
export const getTransactions = (params = {}) => api.get('/admin/transactions', { params });

// Admin - Events
export const getAdminEvents = () => api.get('/admin/events');
export const getApprovedEvents = () => api.get('/admin/events/all/approved');
export const getAdminEvent = (id) => api.get(`/admin/events/${id}`);
export const createEvent = (formData) => api.post('/admin/events', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
});
export const updateEvent = (id, formData) => api.put(`/admin/events/${id}`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
});
export const deleteEvent = (id) => api.delete(`/admin/events/${id}`);

// Admin - Classes
export const createClass = (eventId, name) => api.post(`/admin/events/${eventId}/classes`, { name });
export const deleteClass = (id) => api.delete(`/admin/classes/${id}`);

// Admin - Photos
export const getAdminPhotos = () => api.get('/admin/photos');
export const getAdminPhoto = (id) => api.get(`/admin/photos/${id}`);
export const uploadPhoto = (formData) => api.post('/admin/photos', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
});
export const updatePhoto = (id, formData) => api.put(`/admin/photos/${id}`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
});
export const deletePhoto = (id) => api.delete(`/admin/photos/${id}`);

// Admin - Recaps
export const uploadRecaps = (photoId, formData) => api.post(`/admin/photos/${photoId}/recaps`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
});
export const deleteRecap = (id) => api.delete(`/admin/recaps/${id}`);

// Admin - Pending Events
export const getPendingEvents = () => api.get('/admin/pending-events');
export const approveEvent = (id) => api.post(`/admin/events/${id}/approve`);
export const rejectEvent = (id) => api.post(`/admin/events/${id}/reject`);

// Admin - Users
export const getAdminUsers = () => api.get('/admin/users');
export const createAdminUser = (data) => api.post('/admin/users', data);
export const deleteAdminUser = (id) => api.delete(`/admin/users/${id}`);

// Admin - Sponsors
export const getSponsors = () => api.get('/admin/sponsors');
export const createSponsor = (formData) => api.post('/admin/sponsors', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
});
export const deleteSponsor = (id) => api.delete(`/admin/sponsors/${id}`);

// Admin - Photographers
export const getPhotographers = () => api.get('/admin/photographers');
export const createPhotographer = (formData) => api.post('/admin/photographers', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
});
export const updatePhotographer = (id, formData) => api.put(`/admin/photographers/${id}`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
});
export const deletePhotographer = (id) => api.delete(`/admin/photographers/${id}`);

// Admin - Settings
export const getSettings = () => api.get('/admin/settings');
export const updateSettings = (formData) => api.post('/admin/settings', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
});
export const removeLogo = () => api.delete('/admin/settings/logo');

// Admin - Balance & Withdrawals
export const getBalance = () => api.get('/admin/balance');
export const getAdminBalance = getBalance; // Alias
export const requestWithdrawal = (data) => api.post('/admin/withdrawals', data);
export const getWithdrawals = () => api.get('/admin/withdrawals');
export const getWithdrawalRequests = getWithdrawals; // Alias
export const approveWithdrawal = (id, notes) => api.post(`/admin/withdrawals/${id}/approve`, { notes });
export const rejectWithdrawal = (id, notes) => api.post(`/admin/withdrawals/${id}/reject`, { notes });

// Upcoming Events
export const getUpcomingEvents = () => api.get('/events/upcoming');
export const getAdminUpcomingEvents = () => api.get('/admin/upcoming-events');
export const getAdminUpcomingEvent = (id) => api.get(`/admin/upcoming-events/${id}`);
export const createUpcomingEvent = (formData) => api.post('/admin/upcoming-events', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
});
export const updateUpcomingEvent = (id, formData) => api.put(`/admin/upcoming-events/${id}`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
});
export const deleteUpcomingEvent = (id) => api.delete(`/admin/upcoming-events/${id}`);
export const toggleEventPublish = (id) => api.patch(`/admin/upcoming-events/${id}/toggle-publish`);

// Alias exports for admin pages
export const getAdminTransactions = getTransactions;
export const getAdmins = getAdminUsers;
export const createAdmin = createAdminUser;
export const updateAdmin = (id, data) => api.put(`/admin/users/${id}`, data);
export const deleteAdmin = deleteAdminUser;
export const updateSponsor = (id, formData) => api.put(`/admin/sponsors/${id}`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
});

export default api;

